package com.mythicrealms.creatures.registry;

import com.mythicrealms.creatures.MythicRealmsCreatures;
import com.mythicrealms.creatures.config.CreatureConfig;
import com.mythicrealms.creatures.entity.*;
import net.fabricmc.fabric.api.biome.v1.*;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityType;
import net.minecraft.class_1267;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1314;
import net.minecraft.class_1588;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_1959;
import net.minecraft.class_2378;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9169;
import net.minecraft.core.registries.*;
import net.minecraft.resources.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;

public final class ModEntities {
    public static final class_1299<GoblinScoutEntity> GOBLIN_SCOUT = creature(CreatureKind.GOBLIN_SCOUT, GoblinScoutEntity::new);
    public static final class_1299<GoblinShamanEntity> GOBLIN_SHAMAN = creature(CreatureKind.GOBLIN_SHAMAN, GoblinShamanEntity::new);
    public static final class_1299<OrcWarriorEntity> ORC_WARRIOR = creature(CreatureKind.ORC_WARRIOR, OrcWarriorEntity::new);
    public static final class_1299<MinotaurEntity> MINOTAUR = creature(CreatureKind.MINOTAUR, MinotaurEntity::new);
    public static final class_1299<StoneTrollEntity> STONE_TROLL = creature(CreatureKind.STONE_TROLL, StoneTrollEntity::new);
    public static final class_1299<AncientTreantEntity> ANCIENT_TREANT = companion(CreatureKind.ANCIENT_TREANT, AncientTreantEntity::new);
    public static final class_1299<ForestDryadEntity> FOREST_DRYAD = companion(CreatureKind.FOREST_DRYAD, ForestDryadEntity::new);
    public static final class_1299<GriffinEntity> GRIFFIN = companion(CreatureKind.GRIFFIN, GriffinEntity::new);
    public static final class_1299<DireWolfEntity> DIRE_WOLF = companion(CreatureKind.DIRE_WOLF, DireWolfEntity::new);
    public static final class_1299<WildWyvernEntity> WILD_WYVERN = companion(CreatureKind.WILD_WYVERN, WildWyvernEntity::new);
    public static final class_1299<CaveBasiliskEntity> CAVE_BASILISK = creature(CreatureKind.CAVE_BASILISK, CaveBasiliskEntity::new);
    public static final class_1299<CrystalSpiderEntity> CRYSTAL_SPIDER = creature(CreatureKind.CRYSTAL_SPIDER, CrystalSpiderEntity::new);
    public static final class_1299<ShadowWraithEntity> SHADOW_WRAITH = creature(CreatureKind.SHADOW_WRAITH, ShadowWraithEntity::new);
    public static final class_1299<GraveKnightEntity> GRAVE_KNIGHT = creature(CreatureKind.GRAVE_KNIGHT, GraveKnightEntity::new);
    public static final class_1299<FlameImpEntity> FLAME_IMP = creature(CreatureKind.FLAME_IMP, FlameImpEntity::new);
    public static final class_1299<FrostElementalEntity> FROST_ELEMENTAL = creature(CreatureKind.FROST_ELEMENTAL, FrostElementalEntity::new);
    public static final class_1299<MoonStagEntity> MOON_STAG = companion(CreatureKind.MOON_STAG, MoonStagEntity::new);
    public static final class_1299<SlimeMaidenEntity> SLIME_MAIDEN = companion(CreatureKind.SLIME_MAIDEN, SlimeMaidenEntity::new);
    public static final class_1299<HarpyEntity> HARPY = creature(CreatureKind.HARPY, HarpyEntity::new);
    public static final class_1299<DemonSorceressEntity> DEMON_SORCERESS = creature(CreatureKind.DEMON_SORCERESS, DemonSorceressEntity::new);
    public static final class_1299<CreatureProjectile> CRYSTAL_BOLT = projectile("crystal_bolt", .25f);
    public static final class_1299<CreatureProjectile> DARK_BOLT = projectile("dark_bolt", .3f);
    public static final class_1299<CreatureProjectile> FIRE_BOLT = projectile("fire_bolt", .25f);
    public static final class_1299<CreatureProjectile> ICE_SPIKE = projectile("ice_spike", .3f);
    public static final class_1299<CreatureProjectile> FEATHER_BOLT = projectile("feather_bolt", .2f);
    public static final class_1299<CreatureProjectile> SLIME_BUBBLE = projectile("slime_bubble", .35f);
    public static final class_1299<com.mythicrealms.creatures.magic.WebTrapEntity> WEB_TRAP = webTrap();
    public static final class_1299<CreatureProjectile> ROOT_SHARD = projectile("root_shard", .35f);
    public static final class_1299<CreatureProjectile> VINE_SEED = projectile("vine_seed", .2f);
    public static final class_1299<CreatureProjectile> POISON_BREATH = projectile("poison_breath", .4f);
    public static final class_1299<CreatureProjectile> SHAMAN_BOLT = projectile("shaman_bolt", .25f);
    public static final class_1299<CreatureProjectile> TROLL_BOULDER = projectile("troll_boulder", .55f);

    public static class_2960 id(String path) { return class_2960.method_60655(MythicRealmsCreatures.MOD_ID, path); }
    private static <T extends MythicHostileEntity> class_1299<T> creature(CreatureKind kind, class_1299.class_4049<T> factory) {
        var key = class_5321.method_29179(class_7924.field_41266, id(kind.id));
        var rule = CreatureConfig.INSTANCE.spawning.get(kind.id);
        var builder = FabricEntityType.Builder.createMob(factory, class_1311.field_6302, extra -> extra
            .defaultAttributes(() -> kind.attributes(CreatureConfig.INSTANCE.difficultyMultiplier*rule.difficultyMultiplier))
            .spawnRestriction(class_9169.field_48745, class_2902.class_2903.field_13203,
                (type, level, reason, pos, random) -> allowConfiguredSpawn(kind,level,pos) && random.method_43048(rule.frequency) == 0
                    && ((kind != CreatureKind.STONE_TROLL && kind != CreatureKind.CAVE_BASILISK && kind != CreatureKind.CRYSTAL_SPIDER) || pos.method_10264() < level.method_8410().method_8615() - 8)
                    && ((kind==CreatureKind.FLAME_IMP || kind==CreatureKind.DEMON_SORCERESS) ? level.method_8407()!=class_1267.field_5801 : class_1588.method_20680(type, level, reason, pos, random))));
        if(kind==CreatureKind.FLAME_IMP || kind==CreatureKind.DEMON_SORCERESS)builder.method_19947();
        var type = class_2378.method_39197(class_7923.field_41177, key,
            builder.method_17687(kind.width, kind.height).method_27299(8).method_5905(key));
        finishCreature(kind,type,class_1311.field_6302);
        return type;
    }
    private static <T extends class_1314 & MythicCreature> class_1299<T> companion(CreatureKind kind,class_1299.class_4049<T> factory) {
        var key=class_5321.method_29179(class_7924.field_41266,id(kind.id));
        var rule=CreatureConfig.INSTANCE.spawning.get(kind.id);
        var category=kind==CreatureKind.WILD_WYVERN?class_1311.field_6302:class_1311.field_6294;
        var builder=FabricEntityType.Builder.createMob(factory,category,extra -> extra
            .defaultAttributes(() -> kind.attributes(CreatureConfig.INSTANCE.difficultyMultiplier*rule.difficultyMultiplier))
            .spawnRestriction(class_9169.field_48745,class_2902.class_2903.field_13203,
                (type,level,reason,pos,random) -> allowConfiguredSpawn(kind,level,pos) && random.method_43048(rule.frequency)==0
                    && (kind==CreatureKind.WILD_WYVERN
                        ? level.method_8407()!=class_1267.field_5801 && class_1588.method_20679(level,pos,random)
                        : level.method_22335(pos,0)>8 && (level.method_8320(pos.method_10074()).method_26164(class_3481.field_29822)
                            || kind==CreatureKind.GRIFFIN && level.method_8320(pos.method_10074()).method_26164(class_3481.field_25806)))));
        var type=class_2378.method_39197(class_7923.field_41177,key,builder.method_17687(kind.width,kind.height).method_27299(8).method_5905(key));
        finishCreature(kind,type,category);return type;
    }
    private static void finishCreature(CreatureKind kind,class_1299<?> type,class_1311 category) {
        var rule=CreatureConfig.INSTANCE.spawning.get(kind.id);
        var itemKey = class_5321.method_29179(class_7924.field_41197, id(kind.id + "_spawn_egg"));
        class_1792 egg = class_2378.method_39197(class_7923.field_41178, itemKey,
            new class_1826(new class_1792.class_1793().method_63686(itemKey).method_72499(type)));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> entries.method_45421(egg));
        if (rule.enabled && rule.weight > 0) {
            class_6862<class_1959> tag = class_6862.method_40092(class_7924.field_41236, id("spawns/" + kind.id));
            BiomeModifications.addSpawn(BiomeSelectors.tag(tag), category, type,
                rule.weight, rule.minGroup, rule.maxGroup);
        }
    }
    private static boolean allowConfiguredSpawn(CreatureKind kind,net.minecraft.class_5425 level,net.minecraft.class_2338 pos){
        var rule=CreatureConfig.INSTANCE.spawning.get(kind.id);
        if(!rule.enabled || !rule.dimensions.contains(level.method_8410().method_27983().method_29177().toString()))return false;
        if(rule.biomes.isEmpty())return true;
        var biome=level.method_23753(pos);
        return rule.biomes.stream().anyMatch(value -> value.startsWith("#")
            ? biome.method_40220(class_6862.method_40092(class_7924.field_41236,class_2960.method_60654(value.substring(1))))
            : biome.method_40225(class_5321.method_29179(class_7924.field_41236,class_2960.method_60654(value))));
    }
    private static class_1299<com.mythicrealms.creatures.magic.WebTrapEntity> webTrap(){
        var key=class_5321.method_29179(class_7924.field_41266,id("web_trap"));
        return class_2378.method_39197(class_7923.field_41177,key,
            class_1299.class_1300.method_5903(com.mythicrealms.creatures.magic.WebTrapEntity::new,class_1311.field_17715).method_17687(1.5f,.2f).method_27299(6).method_27300(10).method_5905(key));
    }
    private static class_1299<CreatureProjectile> projectile(String name, float size) {
        var key = class_5321.method_29179(class_7924.field_41266, id(name));
        return class_2378.method_39197(class_7923.field_41177, key,
            class_1299.class_1300.<CreatureProjectile>method_5903(CreatureProjectile::new, class_1311.field_17715)
                .method_17687(size, size).method_27299(6).method_27300(2).method_5905(key));
    }
    public static void initialize() { }
}
