package com.mythicrealms.creatures.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import com.mythicrealms.creatures.MythicRealmsCreatures;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9886;
import net.minecraft.world.item.*;

/** Small survival progression, registered before creature factories can request taming foods. */
public final class ModItems {
    private static final List<class_1792> MATERIALS = new ArrayList<>();
    private static final List<class_1792> EQUIPMENT = new ArrayList<>();
    private static final List<class_1792> FOODS = new ArrayList<>();
    private static final class_9886 ORC_MATERIAL = new class_9886(class_3481.field_49927,
        480, 6, 2, 14, class_6862.method_40092(class_7924.field_41197, id("orc_steel_repair")));

    public static final class_1792 GOBLIN_SCRAP = material("goblin_scrap");
    public static final class_1792 ORC_STEEL = material("orc_steel");
    public static final class_1792 MINOTAUR_HORN = material("minotaur_horn");
    public static final class_1792 TROLL_HEARTSTONE = material("troll_heartstone");
    public static final class_1792 LIVING_WOOD = material("living_wood");
    public static final class_1792 FOREST_ESSENCE = material("forest_essence");
    public static final class_1792 GRIFFIN_FEATHER = material("griffin_feather");
    public static final class_1792 DIRE_FANG = material("dire_fang");
    public static final class_1792 WYVERN_SCALE = material("wyvern_scale");
    public static final class_1792 BASILISK_SCALE = material("basilisk_scale");
    public static final class_1792 CRYSTAL_SHARD = material("crystal_shard");
    public static final class_1792 SHADOW_ESSENCE = material("shadow_essence");
    public static final class_1792 FROST_ESSENCE = material("frost_essence");
    public static final class_1792 INFERNAL_EMBER = material("infernal_ember");
    public static final class_1792 SLIME_PEARL = material("slime_pearl");

    public static final class_1792 SUNSEED_BISCUIT = food("sunseed_biscuit", 5, .6f);
    public static final class_1792 HEARTY_MEAT = food("hearty_meat", 8, .8f);
    public static final class_1792 MOONBLOSSOM = food("moonblossom", 3, .5f);
    public static final class_1792 VENOMOUS_MORSEL = food("venomous_morsel", 4, .3f);

    public static final class_1792 GRIFFIN_SADDLE = equipment("griffin_saddle", p -> new class_1792(p.method_7889(1)));
    public static final class_1792 WYVERN_HARNESS = equipment("wyvern_harness", p -> new class_1792(p.method_7889(1).method_24359()));
    public static final class_1792 CRYSTAL_FANG_SWORD = equipment("crystal_fang_sword", p -> new class_1792(p
        .method_66333(class_9886.field_52588, 3, -2.4f).method_7895(720).method_61648(CRYSTAL_SHARD)));
    public static final class_1792 ORC_WAR_AXE = equipment("orc_war_axe", p -> new class_1743(ORC_MATERIAL, 6, -3.2f, p));
    public static final class_1792 BASILISK_SPEAR = equipment("basilisk_spear", p -> new class_1792(p
        .method_66333(class_9886.field_52587, 3, -2.8f).method_7895(420).method_61648(BASILISK_SCALE)));
    public static final class_1792 FROSTBOUND_STAFF = equipment("frostbound_staff", p -> new FrostStaffItem(p
        .method_66333(class_9886.field_52585, 3, -2.6f).method_7895(260).method_61648(FROST_ESSENCE).method_7894(class_1814.field_8907)));
    public static final class_1792 TWILIGHT_RELIC = equipment("twilight_relic", p -> new class_1792(p.method_7889(1).method_7894(class_1814.field_8903)));

    private ModItems() { }

    private static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory, List<class_1792> collection) {
        var key = class_5321.method_29179(class_7924.field_41197, id(name));
        class_1792 item = class_2378.method_39197(class_7923.field_41178, key, factory.apply(new class_1792.class_1793().method_63686(key)));
        collection.add(item);
        return item;
    }

    private static class_1792 material(String name) { return register(name, class_1792::new, MATERIALS); }
    private static class_2960 id(String name) {
        return class_2960.method_60655(MythicRealmsCreatures.MOD_ID, name);
    }
    private static class_1792 food(String name, int nutrition, float saturationModifier) {
        return register(name, p -> new class_1792(p.method_19265(new class_4174(nutrition, nutrition * saturationModifier * 2, false))), FOODS);
    }
    private static class_1792 equipment(String name, Function<class_1792.class_1793, class_1792> factory) {
        return register(name, factory, EQUIPMENT);
    }

    public static List<class_1792> all() {
        var items = new ArrayList<class_1792>(MATERIALS);
        items.addAll(FOODS);
        items.addAll(EQUIPMENT);
        return List.copyOf(items);
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> MATERIALS.forEach(entries::method_45421));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> FOODS.forEach(entries::method_45421));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(entries -> {
            entries.method_45421(CRYSTAL_FANG_SWORD); entries.method_45421(ORC_WAR_AXE);
            entries.method_45421(BASILISK_SPEAR); entries.method_45421(FROSTBOUND_STAFF);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(GRIFFIN_SADDLE); entries.method_45421(WYVERN_HARNESS); entries.method_45421(TWILIGHT_RELIC);
        });
    }

    /** Vanilla cooldown and durability; no player attack hooks or client-only classes. */
    private static final class FrostStaffItem extends class_1792 {
        private FrostStaffItem(class_1793 properties) { super(properties); }

        @Override
        public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
            var stack = player.method_5998(hand);
            if (player.method_7357().method_7904(stack)) return class_1269.field_5814;
            if (level instanceof class_3218 server) {
                player.method_6092(new class_1293(class_1294.field_5907, 100, 0));
                player.method_7357().method_62835(stack, 240);
                stack.method_71012(3, player, hand);
                com.mythicrealms.creatures.magic.SpellEffects.particles(server,class_2398.field_28013,
                    player.method_23317(),player.method_23318()+1,player.method_23321(),24,.65);
                server.method_8396(null, player.method_24515(), class_3417.field_26980, class_3419.field_15248, .8f, .65f);
            }
            return class_1269.field_5812;
        }
    }
}
