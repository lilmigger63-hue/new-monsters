package com.mythicrealms.creatures.magic;

import net.minecraft.class_10583;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3856;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.storage.*;
import com.mythicrealms.creatures.entity.MythicHostileEntity;

/** Temporary entity-based silk snare; never changes blocks or leaves permanent world debris. */
public final class WebTrapEntity extends class_1297 implements class_3856 {
    private class_10583<class_1309> owner;
    private int remaining=100;
    public WebTrapEntity(class_1299<? extends WebTrapEntity> type,class_1937 level){super(type,level);method_5875(true);}
    public void setOwner(class_1309 owner){this.owner=class_10583.method_73299(owner);}
    @Override public class_1799 method_7495(){return new class_1799(class_1802.field_8786);}
    @Override public boolean method_5863(){return !method_31481();}
    @Override public boolean method_64397(class_3218 level,net.minecraft.class_1282 source,float amount){
        if(amount<=0 || method_31481())return false;method_31472();return true;
    }
    @Override protected void method_5693(class_2945.class_9222 data){ }
    @Override protected void method_5652(class_11372 out){class_10583.method_71612(owner,out,"Owner");out.method_71465("Remaining",remaining);}
    @Override protected void method_5749(class_11368 in){owner=class_10583.method_66262(in,"Owner");remaining=Math.clamp(in.method_71424("Remaining",100),0,100);}
    @Override public void method_5773(){
        super.method_5773();if(!(method_73183() instanceof class_3218 level))return;
        if(--remaining<=0){method_31472();return;}
        var caster=class_10583.method_73301(owner,level);
        if(caster!=null && field_6012%5==0){
            for(var victim:level.method_8390(class_1309.class,method_5829().method_1009(.5,1,.5),target -> target!=caster && caster.method_18395(target)
                && !caster.method_5722(target) && !(caster instanceof MythicHostileEntity && target instanceof MythicHostileEntity))){
                SpellEffects.slow(victim,15,2);victim.method_5844(class_2246.field_10343.method_9564(),new class_243(.25,.05,.25));
            }
            SpellEffects.particles(level,class_2398.field_11207,method_23317(),method_23318()+.4,method_23321(),2,.5);
        }
    }
}
