package com.mythicrealms.creatures.magic;

import com.mythicrealms.creatures.config.CreatureConfig;
import com.mythicrealms.creatures.entity.CreatureKind;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.core.particles.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.effect.*;

/** Bounded, nearby-player-only presentation. No damage, targeting or movement authority. */
public final class SpellEffects {
    private SpellEffects() { }
    private static boolean visible(class_3218 level,double x,double y,double z){
        for(var player:level.method_18456())if(player.method_5649(x,y,z)<=32*32)return true;
        return false;
    }
    public static void particles(class_3218 level,class_2394 particle,double x,double y,double z,int count,double spread){
        int amount=Math.clamp((int)Math.round(count*CreatureConfig.INSTANCE.magicParticleIntensity),0,64);
        if(amount>0 && visible(level,x,y,z))level.method_65096(particle,x,y,z,amount,spread,spread,spread,.02);
    }
    public static void ring(class_3218 level,class_2394 particle,double x,double y,double z,double radius,int requested){
        int amount=Math.clamp((int)Math.round(requested*CreatureConfig.INSTANCE.magicParticleIntensity),0,24);
        if(amount==0 || !visible(level,x,y,z))return;
        for(int i=0;i<amount;i++){
            double angle=Math.PI*2*i/amount;
            level.method_65096(particle,x+Math.cos(angle)*radius,y,z+Math.sin(angle)*radius,1,0,0,0,0);
        }
    }
    public static void telegraph(class_3218 level,class_1308 caster,CreatureKind kind,class_1309 target){
        class_2394 particle=switch(kind){
            case GOBLIN_SHAMAN,FOREST_DRYAD,ANCIENT_TREANT -> class_2398.field_11211;
            case SHADOW_WRAITH,DEMON_SORCERESS -> class_2398.field_11249;
            case CRYSTAL_SPIDER,MOON_STAG -> class_2398.field_11207;
            case FLAME_IMP -> class_2398.field_11240;
            case FROST_ELEMENTAL -> class_2398.field_28013;
            case CAVE_BASILISK -> class_2398.field_22247;
            case WILD_WYVERN,SLIME_MAIDEN -> class_2398.field_11234;
            case HARPY,GRIFFIN -> class_2398.field_23956;
            case MINOTAUR,STONE_TROLL -> new class_2388(class_2398.field_11217,class_2246.field_10340.method_9564());
            default -> null;
        };
        if(particle==null)return;
        double y=caster.method_23318()+Math.min(.8,caster.method_17682()*.45);
        ring(level,particle,caster.method_23317(),y,caster.method_23321(),Math.max(.35,caster.method_17681()*.65),12);
        if(kind==CreatureKind.GOBLIN_SHAMAN || kind==CreatureKind.DEMON_SORCERESS)
            ring(level,particle,caster.method_23317(),y+.15,caster.method_23321(),.3,8);
    }
    public static void gaze(class_3218 level,class_1309 caster,class_1309 target){
        if(CreatureConfig.INSTANCE.magicParticleIntensity==0 || !visible(level,caster.method_23317(),caster.method_23318(),caster.method_23321()))return;
        int points=Math.clamp((int)Math.round(10*CreatureConfig.INSTANCE.magicParticleIntensity),1,16);
        var from=caster.method_33571();var delta=target.method_33571().method_1020(from);
        for(int i=1;i<=points;i++){
            double f=(double)i/points;
            level.method_65096(class_2398.field_22247,from.field_1352+delta.field_1352*f,from.field_1351+delta.field_1351*f,from.field_1350+delta.field_1350*f,1,0,0,0,0);
        }
    }
    public static void slow(class_1309 target,int ticks,int strength){target.method_6092(new class_1293(class_1294.field_5909,ticks,strength));}
}
