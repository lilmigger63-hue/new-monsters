package com.mythicrealms.creatures.entity.mount;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_2902;

/** Short, bounded flights above local loaded terrain; yields to owner following and combat. */
final class MountAirWanderGoal extends class_1352 {
    private final MythicMountEntity mount;
    private int ticks;
    private class_2338 destination;
    MountAirWanderGoal(MythicMountEntity mount){this.mount=mount;method_6265(EnumSet.of(class_4134.field_18405));}
    @Override public boolean method_6264(){
        if(mount.method_5782() || mount.method_24345() || mount.method_5968()!=null || mount.method_6181() || mount.method_59922().method_43048(140)!=0)return false;
        var pos=mount.method_24515().method_10069(mount.method_59922().method_43048(17)-8,0,mount.method_59922().method_43048(17)-8);
        if(!mount.method_73183().method_22340(pos))return false;
        int floor=mount.method_73183().method_8624(class_2902.class_2903.field_13203,pos.method_10263(),pos.method_10260());
        if(Math.abs(floor-mount.method_23318())>16)return false;
        destination=new class_2338(pos.method_10263(),Math.min(floor+3,mount.method_73183().method_31600()-3),pos.method_10260());return true;
    }
    @Override public void method_6269(){ticks=0;mount.setFlying(true);mount.method_5942().method_6337(destination.method_10263()+.5,destination.method_10264(),destination.method_10260()+.5,.8);}
    @Override public boolean method_6266(){return ticks<100 && !mount.method_5942().method_6357() && !mount.method_5782() && mount.method_5968()==null;}
    @Override public void method_6268(){ticks++;}
    @Override public void method_6270(){mount.method_5942().method_6340();}
}
