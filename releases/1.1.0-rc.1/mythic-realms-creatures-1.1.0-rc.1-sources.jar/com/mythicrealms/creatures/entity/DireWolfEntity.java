package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;

public final class DireWolfEntity extends MythicMountEntity {
    public DireWolfEntity(class_1299<? extends DireWolfEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.DIRE_WOLF;}
    @Override public class_1792 tamingItem(){return class_1802.field_8606;}
    @Override public class_1792 healingItem(){return class_1802.field_8046;}
    @Override protected class_3414 method_5994(){return class_3417.field_57074.get(net.minecraft.class_10824.class_10825.field_57092).comp_3779().comp_349();}
}
