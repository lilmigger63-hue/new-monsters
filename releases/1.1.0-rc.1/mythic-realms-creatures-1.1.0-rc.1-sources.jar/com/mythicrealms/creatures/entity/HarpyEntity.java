package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;

public final class HarpyEntity extends AerialHostileEntity {
    public HarpyEntity(class_1299<? extends HarpyEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.HARPY;}
    @Override protected String attackAnimation(){return method_5968()!=null && method_5858(method_5968())<9?"swoop":"cast";}
    @Override public boolean ranged(){return true;}
    @Override public boolean reposition(class_1309 target){
        if(field_6012%100<28 && method_5858(target)>7){
            if(field_6012%7==0)method_5942().method_6337(target.method_23317(),target.method_23318()+.5,target.method_23321(),1.3);return true;
        }
        if(field_6012%100>80 && method_5858(target)<36){
            if(field_6012%7==0)method_5942().method_6337(method_23317(),target.method_23318()+4,method_23321(),1.1);return true;
        }
        return false;
    }
    @Override public void performAttack(class_3218 level,class_1309 target){
        if(method_5858(target)<9)melee(level,target,3,1.25);
        else if(method_5858(target)<121)CreatureProjectile.launch(ModEntities.FEATHER_BOLT,this,target,1.6f);
    }
}
