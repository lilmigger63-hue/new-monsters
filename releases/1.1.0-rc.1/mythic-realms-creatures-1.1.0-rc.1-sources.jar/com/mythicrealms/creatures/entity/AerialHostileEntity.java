package com.mythicrealms.creatures.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1331;
import net.minecraft.class_1352;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.navigation.*;
import java.util.EnumSet;

/** Loaded-chunk-bounded flying navigation shared by spectral and winged enemies. */
public abstract class AerialHostileEntity extends MythicHostileEntity {
    protected AerialHostileEntity(class_1299<? extends AerialHostileEntity> type,class_1937 level){super(type,level);field_6207=new class_1331(this,14,true);}
    @Override protected class_1408 method_5965(class_1937 level){var nav=new class_1407(this,level);nav.method_6354(true);return nav;}
    @Override protected void method_5959(){
        super.method_5959();
        field_6201.method_6277(5,new class_1352(){
            private int ticks;
            {method_6265(EnumSet.of(Flag.field_18405));}
            @Override public boolean method_6264(){return method_5968()==null && method_59922().method_43048(80)==0;}
            @Override public void method_6269(){
                ticks=0;var pos=method_24515().method_10069(method_59922().method_43048(13)-6,0,method_59922().method_43048(13)-6);
                if(!method_73183().method_22340(pos))return;
                int ground=method_73183().method_8624(class_2902.class_2903.field_13203,pos.method_10263(),pos.method_10260());
                double y=Math.min(Math.max(method_23318()-3,ground+2),Math.min(method_23318()+4,method_73183().method_31600()-3));
                method_5942().method_6337(pos.method_10263()+.5,y,pos.method_10260()+.5,.8);
            }
            @Override public boolean method_6266(){return ++ticks<100 && method_5968()==null && !method_5942().method_6357();}
            @Override public void method_6270(){method_5942().method_6340();}
        });
    }
    @Override public void method_6091(class_243 input){
        if(method_66247()){
            method_5875(true);field_6017=0;method_5724(.06f,input);
            class_243 velocity=method_18798();
            if(method_5942().method_6357() && method_5968()==null)velocity=new class_243(velocity.field_1352*.8,-.05,velocity.field_1350*.8);
            if(velocity.method_1033()>.55)velocity=velocity.method_1029().method_1021(.55);
            if(method_23318()>method_73183().method_31600()-3)velocity=new class_243(velocity.field_1352,Math.min(0,velocity.field_1351),velocity.field_1350);
            if(!method_73183().method_22340(class_2338.method_49638(method_73189().method_1019(velocity))))velocity=class_243.field_1353;
            method_18799(velocity);method_5784(class_1313.field_6308,velocity);method_18799(velocity.method_1021(.85));method_29242(false);
        }else super.method_6091(input);
    }
    @Override public boolean method_5747(double distance,float multiplier,net.minecraft.class_1282 source){return false;}
}
