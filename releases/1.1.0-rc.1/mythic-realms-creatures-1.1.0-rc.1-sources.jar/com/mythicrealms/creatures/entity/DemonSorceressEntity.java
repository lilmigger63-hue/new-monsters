package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.magic.SpellEffects;
import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;

public final class DemonSorceressEntity extends MythicHostileEntity {
    private int teleportCooldown;
    public DemonSorceressEntity(class_1299<? extends DemonSorceressEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.DEMON_SORCERESS;}
    @Override public boolean ranged(){return true;}
    public boolean teleportAway(class_3218 level,class_1309 target){
        if(teleportCooldown>0)return false;
        for(int attempt=0;attempt<4;attempt++){
            double x=method_23317()+method_59922().method_43048(9)-4,z=method_23321()+method_59922().method_43048(9)-4;
            if(!level.method_22340(class_2338.method_49637(x,method_23318(),z)))continue;
            if(target.method_5649(x,method_23318(),z)<16)continue;
            if(method_6082(x,method_23318()+2,z,true)){
                triggerAnim("action","teleport");teleportCooldown=100;SpellEffects.particles(level,class_2398.field_11214,method_23317(),method_23318()+1,method_23321(),16,.6);return true;
            }
        }
        teleportCooldown=30;return false;
    }
    @Override public void performAttack(class_3218 level,class_1309 target){
        if(method_5858(target)<16)teleportAway(level,target);
        if(method_5858(target)<225)CreatureProjectile.launch(ModEntities.DARK_BOLT,this,target,1.2f);
    }
    @Override protected void method_5958(class_3218 level){super.method_5958(level);if(teleportCooldown>0)--teleportCooldown;}
}
