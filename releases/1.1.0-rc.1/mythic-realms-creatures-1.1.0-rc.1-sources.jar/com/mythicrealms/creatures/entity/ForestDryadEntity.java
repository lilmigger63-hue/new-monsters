package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.world.entity.*;

public final class ForestDryadEntity extends ForestGuardianEntity {
    private class_1309 healingTarget;
    private int healWindup,healCooldown;
    public ForestDryadEntity(class_1299<? extends ForestDryadEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.FOREST_DRYAD;}
    @Override public boolean busyCasting(){return healWindup>0;}
    @Override public void performAttack(class_3218 level,class_1309 target){CreatureProjectile.launch(ModEntities.VINE_SEED,this,target,1.15f);}
    public boolean beginHealing(class_1309 target){
        if(healCooldown>0 || healWindup>0 || combatTimeline().isWindingUp() || !friendly(target)
            || target.method_6032()>=target.method_6063() || method_5858(target)>64 || !method_5985().method_6369(target))return false;
        healingTarget=target;healWindup=15;healCooldown=120;method_5942().method_6340();
        triggerAnim("action","cast");method_5783(class_3417.field_15119,.5f,1.3f);return true;
    }
    private boolean friendly(class_1309 target){
        return target.method_5805() && target!=method_5968() && (target instanceof ForestGuardianEntity
            || target instanceof class_1657 || target instanceof MythicMountEntity mount && mount.method_6181());
    }
    @Override protected void method_5958(class_3218 level){
        super.method_5958(level);
        if(healCooldown>0)--healCooldown;
        if(healWindup>0 && --healWindup==0){
            var target=healingTarget;healingTarget=null;
            if(target!=null && friendly(target) && method_5858(target)<64 && method_5985().method_6369(target)){
                target.method_6025(4);
                com.mythicrealms.creatures.magic.SpellEffects.particles(level,class_2398.field_11211,target.method_23317(),target.method_23318()+1,target.method_23321(),8,.4);
            }
        }
        if(field_6012%40==0 && healCooldown==0){
            for(var target:level.method_8390(class_1309.class,method_5829().method_1014(7),this::friendly)){
                if(beginHealing(target))break;
            }
        }
    }
}
