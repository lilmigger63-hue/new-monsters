package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.config.CreatureConfig;
import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1266;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1400;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.sounds.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;

public final class WildWyvernEntity extends MythicMountEntity {
    public WildWyvernEntity(class_1299<? extends WildWyvernEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.WILD_WYVERN;}
    @Override public class_1792 tamingItem(){return class_1802.field_8711;}
    @Override public boolean canBeTamed(){return isRareVariant();}
    @Override protected void method_5959(){
        super.method_5959();
        field_6185.method_6277(4,new class_1400<class_1657>(this,class_1657.class,true){
            @Override public boolean method_6264(){return !method_6181() && super.method_6264();}
            @Override public boolean method_6266(){return !method_6181() && super.method_6266();}
        });
    }
    @Override public class_1315 method_5943(class_5425 level,class_1266 difficulty,class_3730 reason,class_1315 data){
        setRareVariant(method_59922().method_43048(CreatureConfig.INSTANCE.rareWyvernChance)==0);
        return super.method_5943(level,difficulty,reason,data);
    }
    @Override public void performAttack(class_3218 level,class_1309 target){
        if(method_18395(target) && method_5858(target)<100 && method_5985().method_6369(target)){
            CreatureProjectile.launch(ModEntities.POISON_BREATH,this,target,1.2f);
            method_5783(class_3417.field_14671,.5f,1.5f);
        }
    }
    @Override protected class_3414 method_5994(){return class_3417.field_15024;}
}
