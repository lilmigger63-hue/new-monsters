package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;

public final class GriffinEntity extends MythicMountEntity {
    public GriffinEntity(class_1299<? extends GriffinEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.GRIFFIN;}
    @Override public class_1792 tamingItem(){return class_1802.field_8504;}
    @Override protected class_3414 method_5994(){return class_3417.field_15132;}
}
