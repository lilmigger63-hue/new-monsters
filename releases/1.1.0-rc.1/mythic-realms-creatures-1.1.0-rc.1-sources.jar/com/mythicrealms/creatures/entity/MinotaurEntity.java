package com.mythicrealms.creatures.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;
import java.util.HashSet;
import java.util.Set;

public final class MinotaurEntity extends MythicHostileEntity {
    private int chargeTicks;
    private class_1309 chargeTarget;
    private class_243 chargeDirection = class_243.field_1353;
    private final Set<Integer> hit = new HashSet<>();
    public MinotaurEntity(class_1299<? extends MinotaurEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.MINOTAUR; }
    @Override public boolean busy() { return chargeTicks > 0; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        if (method_5858(target) < 12) {
            for (class_1309 player : level.method_8390(class_1309.class, method_5829().method_1014(2.2), p -> areaVictim(p, target)))
                melee(level, player, 3.5, 1);
        } else if (method_5858(target) < 100) {
            chargeDirection = target.method_73189().method_1020(method_73189()).method_18805(1, 0, 1).method_1029().method_1021(.65);
            chargeTicks = 16; chargeTarget = target; hit.clear();
        }
    }
    @Override protected void method_5958(class_3218 level) {
        super.method_5958(level);
        if (chargeTicks <= 0) return;
        --chargeTicks;
        if (field_5976) { chargeTicks = 0; return; }
        method_5942().method_6340();
        method_18800(chargeDirection.field_1352, method_18798().field_1351, chargeDirection.field_1350);
        for (class_1309 player : level.method_8390(class_1309.class, method_5829().method_1014(.7), p -> areaVictim(p, chargeTarget))) {
            if (hit.add(player.method_5628())) {
                melee(level, player, 3, 1.25);
                player.method_6005(1, method_23317() - player.method_23317(), method_23321() - player.method_23321());
            }
        }
    }
}
