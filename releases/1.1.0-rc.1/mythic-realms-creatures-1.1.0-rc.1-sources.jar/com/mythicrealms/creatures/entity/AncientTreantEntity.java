package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;

public final class AncientTreantEntity extends ForestGuardianEntity {
    public AncientTreantEntity(class_1299<? extends AncientTreantEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.ANCIENT_TREANT;}
    @Override public void performAttack(class_3218 level,class_1309 target){
        CreatureProjectile.launch(ModEntities.ROOT_SHARD,this,target,1.05f);
    }
}
