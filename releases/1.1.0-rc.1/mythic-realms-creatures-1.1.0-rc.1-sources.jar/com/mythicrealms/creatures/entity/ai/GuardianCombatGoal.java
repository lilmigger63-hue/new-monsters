package com.mythicrealms.creatures.entity.ai;

import com.mythicrealms.creatures.entity.CreatureCombatant;
import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import java.util.EnumSet;
import net.minecraft.class_1352;

/** Shared pursuit and windup rules for neutral guardians and tameable creatures. */
public final class GuardianCombatGoal extends class_1352 {
    private final CreatureCombatant fighter;
    public GuardianCombatGoal(CreatureCombatant fighter) {
        this.fighter=fighter;method_6265(EnumSet.of(class_4134.field_18405,class_4134.field_18406));
    }
    @Override public boolean method_6264() {
        var mob=fighter.actor();
        return fighter.canEngage() && mob.method_5968()!=null && mob.method_5968().method_5805() && mob.method_18395(mob.method_5968());
    }
    @Override public boolean method_6266() { return method_6264() && fighter.actor().method_5858(fighter.actor().method_5968())<1600; }
    @Override public boolean method_38846() { return true; }
    @Override public void method_6270() { fighter.interruptAttack();fighter.actor().method_5942().method_6340(); }
    @Override public void method_6268() {
        var mob=fighter.actor();var target=mob.method_5968();if(target==null)return;
        mob.method_5988().method_6226(target,30,30);
        if (fighter.combatTimeline().isWindingUp() || fighter.busyCasting()) { mob.method_5942().method_6340();return; }
        double distance=mob.method_5858(target);
        if (mob instanceof MythicMountEntity mount && mount.canFly() && (distance>36 || target.method_23318()>mob.method_23318()+2)) mount.setFlying(true);
        if(distance>fighter.kind().range*fighter.kind().range || !mob.method_5985().method_6369(target)) {
            if(mob.field_6012%com.mythicrealms.creatures.config.CreatureConfig.INSTANCE.aiUpdateInterval==0)mob.method_5942().method_6335(target,1.1);
        } else {
            mob.method_5942().method_6340();fighter.beginAttack(target);
        }
    }
}
