package com.mythicrealms.creatures.entity.ai;

import com.mythicrealms.creatures.entity.MythicHostileEntity;
import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_243;

public final class CreatureCombatGoal extends class_1352 {
    private final MythicHostileEntity mob;
    public CreatureCombatGoal(MythicHostileEntity mob) {
        this.mob = mob;
        method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }
    @Override public boolean method_6264() { return mob.method_5968() != null && mob.method_5968().method_5805(); }
    @Override public boolean method_6266() { return method_6264() && mob.method_5858(mob.method_5968()) < 1600; }
    @Override public boolean method_38846() { return true; }
    @Override public void method_6270() { mob.interruptAttack(); mob.method_5942().method_6340(); }
    @Override public void method_6268() {
        var target = mob.method_5968();
        if (target == null) return;
        mob.method_5988().method_6226(target, 30, 30);
        if (mob.busy()) return;
        if (mob.attack.isWindingUp()) { mob.method_5942().method_6340(); return; }
        double distance = mob.method_5858(target);
        if (mob.reposition(target)) return;
        if (mob.ranged() && distance < 16) {
            if(mob.field_6012 % com.mythicrealms.creatures.config.CreatureConfig.INSTANCE.aiUpdateInterval == 0) {
                class_243 retreat = mob.method_73189().method_1020(target.method_73189()).method_1029().method_1021(4).method_1019(mob.method_73189());
                mob.method_5942().method_6337(retreat.field_1352, retreat.field_1351, retreat.field_1350, 1.1);
            }
            if(mob.method_5985().method_6369(target))mob.tryAttack(target);
        } else if (distance > mob.kind().range * mob.kind().range || !mob.method_5985().method_6369(target)) {
            if (mob.field_6012 % com.mythicrealms.creatures.config.CreatureConfig.INSTANCE.aiUpdateInterval == 0) mob.method_5942().method_6335(target, 1.1);
        } else {
            mob.method_5942().method_6340();
            mob.tryAttack(target);
        }
    }
}
