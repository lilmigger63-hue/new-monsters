package com.mythicrealms.creatures.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_8103;
import net.minecraft.world.entity.*;

public final class OrcWarriorEntity extends MythicHostileEntity {
    public OrcWarriorEntity(class_1299<? extends OrcWarriorEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.ORC_WARRIOR; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        melee(level, target, 2.8, 1);
        if (method_5858(target) < 8) target.method_6005(.6, method_23317() - target.method_23317(), method_23321() - target.method_23321());
    }
    @Override public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        var from = source.method_5510();
        if (attack != null && !attack.isWindingUp() && method_5968() != null && from != null
            && !source.method_48789(class_8103.field_56242)
            && from.method_1020(method_73189()).method_1029().method_1026(method_5720()) > .5) {
            amount *= .45f;
            method_5783(class_3417.field_15150.comp_349(), .7f, .8f);
        }
        return super.method_64397(level, source, amount);
    }
}
