package com.mythicrealms.creatures.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;

public final class GoblinScoutEntity extends MythicHostileEntity {
    public GoblinScoutEntity(class_1299<? extends GoblinScoutEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.GOBLIN_SCOUT; }
    @Override public boolean reposition(class_1309 target) {
        if (method_5858(target) < 9 || method_5858(target) > 49 || field_6012 % 60 >= 14) return false;
        if (field_6012 % 7 == 0) {
            class_243 offset = method_73189().method_1020(target.method_73189()).method_1029();
            double side = (method_5628() & 1) == 0 ? 1 : -1;
            class_243 point = target.method_73189().method_1031(-offset.field_1350 * 2.5 * side, 0, offset.field_1352 * 2.5 * side);
            method_5942().method_6337(point.field_1352, point.field_1351, point.field_1350, 1.2);
        }
        return true;
    }
    @Override protected void method_5958(class_3218 level) {
        super.method_5958(level);
        var target=method_5968();
        if(field_6012%40!=0 || target==null || !target.method_5805() || !method_18395(target))return;
        int recruited=0;
        for(var ally:level.method_18467(GoblinScoutEntity.class,method_5829().method_1014(8))) {
            if(ally==this || ally.method_5968()!=null || !ally.method_18395(target)
                || ally.method_5858(target)>28*28 || !ally.method_5985().method_6369(target))continue;
            ally.method_5980(target);
            if(++recruited==4)break;
        }
    }
    @Override public void performAttack(class_3218 level, class_1309 target) { melee(level, target, 2.1, 1); }
}
