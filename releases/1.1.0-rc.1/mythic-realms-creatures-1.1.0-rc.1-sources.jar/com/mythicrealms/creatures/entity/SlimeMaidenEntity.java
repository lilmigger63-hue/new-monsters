package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;

public final class SlimeMaidenEntity extends ForestGuardianEntity {
    public SlimeMaidenEntity(class_1299<? extends SlimeMaidenEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.SLIME_MAIDEN;}
    @Override public void performAttack(class_3218 level,class_1309 target){if(method_5858(target)<100)CreatureProjectile.launch(ModEntities.SLIME_BUBBLE,this,target,1.1f);}
    @Override protected void method_5958(class_3218 level){
        super.method_5958(level);
        if(method_24828() && field_6012%35==0 && !combatTimeline().isWindingUp()){
            method_18800(method_18798().field_1352,.3,method_18798().field_1350);method_5783(class_3417.field_14919,.4f,1.3f);
        }
    }
    @Override protected class_3414 method_5994(){return class_3417.field_15095;}
    @Override protected class_3414 method_6002(){return class_3417.field_14763;}
}
