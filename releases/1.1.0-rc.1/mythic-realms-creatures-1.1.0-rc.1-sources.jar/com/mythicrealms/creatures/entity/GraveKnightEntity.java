package com.mythicrealms.creatures.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_8103;
import net.minecraft.world.entity.*;

public final class GraveKnightEntity extends MythicHostileEntity {
    private int combo;
    public GraveKnightEntity(class_1299<? extends GraveKnightEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.GRAVE_KNIGHT;}
    @Override protected String attackAnimation(){return switch(combo%3){case 1 -> "attack_two";case 2 -> "heavy";default -> "attack";};}
    @Override public void performAttack(class_3218 level,class_1309 target){
        boolean heavy=++combo%3==0;
        melee(level,target,2.8,heavy?1.5:1);
        if(heavy && method_5858(target)<8)target.method_6005(.7,method_23317()-target.method_23317(),method_23321()-target.method_23321());
    }
    @Override public boolean method_64397(class_3218 level,class_1282 source,float damage){
        var from=source.method_5510();
        if(attack!=null && !attack.isWindingUp() && method_5968()!=null && from!=null
            && !source.method_48789(class_8103.field_56242) && from.method_1020(method_73189()).method_1029().method_1026(method_5720())>.5)damage*=.6f;
        return super.method_64397(level,source,damage);
    }
}
