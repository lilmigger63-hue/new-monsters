package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1408;
import net.minecraft.class_1410;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.network.syncher.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.navigation.*;

public final class CrystalSpiderEntity extends MythicHostileEntity {
    private static final class_2940<Boolean> CLIMBING=class_2945.method_12791(CrystalSpiderEntity.class,class_2943.field_13323);
    public CrystalSpiderEntity(class_1299<? extends CrystalSpiderEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.CRYSTAL_SPIDER;}
    @Override protected class_1408 method_5965(class_1937 level){return new class_1410(this,level);}
    @Override protected void method_5693(class_2945.class_9222 data){super.method_5693(data);data.method_56912(CLIMBING,false);}
    @Override public boolean method_6101(){return field_6011.method_12789(CLIMBING);}
    @Override public void method_5773(){super.method_5773();if(!method_73183().method_8608())field_6011.method_12778(CLIMBING,field_5976);}
    @Override public boolean ranged(){return true;}
    @Override public void performAttack(class_3218 level,class_1309 target){if(method_5858(target)<169)CreatureProjectile.launch(ModEntities.CRYSTAL_BOLT,this,target,1.2f);}
}
