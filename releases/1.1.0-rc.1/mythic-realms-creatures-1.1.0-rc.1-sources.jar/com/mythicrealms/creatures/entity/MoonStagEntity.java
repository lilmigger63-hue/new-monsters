package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import com.mythicrealms.creatures.magic.SpellEffects;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;

public final class MoonStagEntity extends MythicMountEntity {
    public MoonStagEntity(class_1299<? extends MoonStagEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.MOON_STAG;}
    @Override public boolean canFly(){return false;}
    @Override public class_1792 tamingItem(){return class_1802.field_8071;}
    @Override public class_1792 healingItem(){return class_1802.field_28659;}
    @Override protected class_3414 method_5994(){return class_3417.field_14947;}
    @Override protected void method_5958(class_3218 level){
        super.method_5958(level);
        if(method_6181() && field_6012%240==0 && level.method_8532()%24000>=13000 && method_35057()!=null && method_5858(method_35057())<36){
            var owner=method_35057();if(owner.method_6032()<owner.method_6063()){
                owner.method_6025(2);triggerAnim("action","cast");SpellEffects.particles(level,class_2398.field_11207,method_23317(),method_23318()+1,method_23321(),6,.5);
            }
        }
    }
}
