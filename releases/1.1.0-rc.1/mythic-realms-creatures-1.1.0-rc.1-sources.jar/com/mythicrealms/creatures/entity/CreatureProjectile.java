package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_3857;
import net.minecraft.class_3966;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.*;

public final class CreatureProjectile extends class_3857 {
    public CreatureProjectile(class_1299<? extends CreatureProjectile> type, class_1937 level) { super(type, level); }
    @Override protected class_1792 method_16942() {
        if(method_5864()==ModEntities.TROLL_BOULDER)return class_1802.field_20412;
        if(method_5864()==ModEntities.ROOT_SHARD)return class_1802.field_8600;
        if(method_5864()==ModEntities.VINE_SEED)return class_1802.field_17535;
        if(method_5864()==ModEntities.POISON_BREATH)return class_1802.field_8680;
        if(method_5864()==ModEntities.CRYSTAL_BOLT)return class_1802.field_27063;
        if(method_5864()==ModEntities.FIRE_BOLT)return class_1802.field_8814;
        if(method_5864()==ModEntities.ICE_SPIKE)return class_1802.field_8081;
        if(method_5864()==ModEntities.DARK_BOLT)return class_1802.field_8634;
        if(method_5864()==ModEntities.FEATHER_BOLT)return class_1802.field_8153;
        return class_1802.field_8777;
    }
    public static void launch(class_1299<CreatureProjectile> type, class_1309 caster, class_1309 target, float speed) {
        CreatureProjectile bolt = new CreatureProjectile(type, caster.method_73183());
        bolt.method_7432(caster);
        bolt.method_5814(caster.method_23317(), caster.method_23320() - .15, caster.method_23321());
        // Bubbles launched near torso height need a lower aim point to avoid arcing over heads.
        class_243 aim=type==ModEntities.SLIME_BUBBLE?target.method_73189().method_1031(0,target.method_17682()*.5,0):target.method_33571();
        class_243 delta = aim.method_1020(bolt.method_73189());
        bolt.method_7485(delta.field_1352, delta.field_1351 + delta.method_37267() * .1, delta.field_1350, speed, 2);
        caster.method_73183().method_8649(bolt);
    }
    @Override protected boolean method_26958(class_1297 entity) {
        if(!super.method_26958(entity))return false;
        if(method_24921() instanceof class_1309 owner && entity instanceof class_1309 target
            && (owner.method_5722(target) || !owner.method_18395(target)))return false;
        if(method_5864()==ModEntities.ROOT_SHARD || method_5864()==ModEntities.VINE_SEED)return !(entity instanceof ForestGuardianEntity);
        if(method_24921() instanceof MythicHostileEntity && entity instanceof MythicHostileEntity)return false;
        return true;
    }
    @Override protected void method_7454(class_3966 result) {
        super.method_7454(result);
        if (method_73183() instanceof class_3218 level && result.method_17782() instanceof class_1309 target) {
            boolean rock = method_5864() == ModEntities.TROLL_BOULDER;
            float damage = method_24921() instanceof class_1309 owner
                ? (float)owner.method_45325(net.minecraft.class_5134.field_23721) : 4;
            boolean damaged=target.method_64397(level, method_48923().method_48811(this, method_24921()), damage);
            if(!damaged)return;
            if(method_5864()==ModEntities.ROOT_SHARD || method_5864()==ModEntities.VINE_SEED)
                target.method_37222(new class_1293(class_1294.field_5909,80,method_5864()==ModEntities.ROOT_SHARD?2:1),method_24921());
            else if(method_5864()==ModEntities.FIRE_BOLT || method_5864()==ModEntities.SHAMAN_BOLT)target.method_5639(2);
            else if(method_5864()==ModEntities.CRYSTAL_BOLT){
                target.method_37222(new class_1293(class_1294.field_5909,60,1),method_24921());
                var web=ModEntities.WEB_TRAP.method_5883(level,class_3730.field_16461);
                if(web!=null && method_24921() instanceof class_1309 caster){web.setOwner(caster);web.method_5814(target.method_23317(),target.method_23318()+.1,target.method_23321());level.method_8649(web);}
            }
            else if(method_5864()==ModEntities.ICE_SPIKE)target.method_37222(new class_1293(class_1294.field_5909,80,2),method_24921());
            else if(method_5864()==ModEntities.DARK_BOLT){target.method_37222(new class_1293(class_1294.field_5911,100,0),method_24921());target.method_37222(new class_1293(class_1294.field_38092,50,0),method_24921());}
            else if(method_5864()==ModEntities.SLIME_BUBBLE){target.method_37222(new class_1293(class_1294.field_5909,50,1),method_24921());target.method_18799(target.method_18798().method_1031(0,.15,0));}
            else if(method_5864()==ModEntities.FEATHER_BOLT)target.method_6005(.25,-method_18798().field_1352,-method_18798().field_1350);
            else if(!rock)target.method_37222(new class_1293(class_1294.field_5899,60,0),method_24921());
            else target.method_6005(.7, -method_18798().field_1352, -method_18798().field_1350);
        }
    }
    @Override protected void method_7488(class_239 result) {
        super.method_7488(result);
        if (method_73183() instanceof class_3218 level) {
            com.mythicrealms.creatures.magic.SpellEffects.particles(level,
                method_5864()==ModEntities.TROLL_BOULDER?class_2398.field_11204:method_5864()==ModEntities.FIRE_BOLT?class_2398.field_11240:
                method_5864()==ModEntities.ICE_SPIKE?class_2398.field_28013:method_5864()==ModEntities.DARK_BOLT?class_2398.field_11249:class_2398.field_11211,
                method_23317(),method_23318(),method_23321(),5,.15);
            com.mythicrealms.creatures.magic.SpellEffects.ring(level,
                method_5864()==ModEntities.ICE_SPIKE?class_2398.field_28013:method_5864()==ModEntities.DARK_BOLT?class_2398.field_11249:
                method_5864()==ModEntities.CRYSTAL_BOLT?class_2398.field_11207:class_2398.field_11204,method_23317(),method_23318()+.1,method_23321(),.55,10);
            method_31472();
        }
    }
    @Override public void method_5773() {
        // Vanilla's growing margin can move the ray start inside the target box;
        // its segment clip then misses the entry face. Resolve only that short age window.
        if(method_73183() instanceof class_3218 && field_6012>=3 && field_6012<=8){
            float margin=net.minecraft.class_1675.method_71624(this);
            for(class_1297 entity:method_73183().method_8333(this,method_5829().method_1014(margin),this::method_26958)){
                if(!entity.method_5829().method_1014(margin).method_1006(method_73189()))continue;
                var sight=method_73183().method_17742(new net.minecraft.class_3959(method_73189(),entity.method_5829().method_1005(),
                    net.minecraft.class_3959.class_3960.field_17558,net.minecraft.class_3959.class_242.field_1348,this));
                if(sight.method_17783()!=class_239.class_240.field_1333)continue;
                method_59860(new class_3966(entity,method_73189()));
                break;
            }
            if(method_31481())return;
        }
        super.method_5773();
        if (!method_73183().method_8608() && field_6012 > 100) method_31472();
        if(method_73183() instanceof class_3218 level && field_6012%6==0 && method_5864()!=ModEntities.TROLL_BOULDER) {
            var particle=method_5864()==ModEntities.FIRE_BOLT?class_2398.field_11240:
                method_5864()==ModEntities.ICE_SPIKE?class_2398.field_28013:method_5864()==ModEntities.DARK_BOLT?class_2398.field_11249:
                method_5864()==ModEntities.CRYSTAL_BOLT?class_2398.field_11207:class_2398.field_11211;
            com.mythicrealms.creatures.magic.SpellEffects.particles(level,particle,method_23317(),method_23318(),method_23321(),1,.05);
        }
    }
}
