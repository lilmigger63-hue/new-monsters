package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;

public final class ShadowWraithEntity extends AerialHostileEntity {
    public ShadowWraithEntity(class_1299<? extends ShadowWraithEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.SHADOW_WRAITH;}
    @Override public boolean ranged(){return true;}
    @Override public void performAttack(class_3218 level,class_1309 target){if(method_5858(target)<169)CreatureProjectile.launch(ModEntities.DARK_BOLT,this,target,1.05f);}
    @Override protected class_3414 method_5994(){return class_3417.field_23060.comp_349();}
}
