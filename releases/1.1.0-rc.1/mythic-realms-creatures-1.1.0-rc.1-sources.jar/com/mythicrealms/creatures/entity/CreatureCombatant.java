package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.combat.AttackTimeline;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.world.entity.*;

public interface CreatureCombatant extends MythicCreature {
    AttackTimeline combatTimeline();
    boolean beginAttack(class_1309 target);
    void interruptAttack();
    default class_1314 actor() { return (class_1314)this; }
    default boolean canEngage() { return actor().method_5805(); }
    default boolean busyCasting() { return false; }
}
