package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.magic.SpellEffects;
import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;

public final class FrostElementalEntity extends MythicHostileEntity {
    public FrostElementalEntity(class_1299<? extends FrostElementalEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.FROST_ELEMENTAL;}
    @Override public boolean ranged(){return true;}
    @Override public void performAttack(class_3218 level,class_1309 target){
        if(method_5858(target)<16){
            for(var victim:level.method_8390(class_1309.class,method_5829().method_1014(4),candidate -> areaVictim(candidate,target))){
                if(method_5985().method_6369(victim) && victim.method_64397(level,method_48923().method_48812(this),(float)method_45325(net.minecraft.class_5134.field_23721)))SpellEffects.slow(victim,80,2);
            }
            SpellEffects.particles(level,class_2398.field_28013,method_23317(),method_23318()+.6,method_23321(),18,2);
        }else if(method_5858(target)<169)CreatureProjectile.launch(ModEntities.ICE_SPIKE,this,target,1.2f);
    }
}
