package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.GoblinShamanEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

/** Inherits the original GoblinShaman goals, cooperation and server combat timeline. */
public abstract class ShamanProfileEntity extends GoblinShamanEntity implements ProfiledCreature {
    protected ShamanProfileEntity(class_1299<? extends ShamanProfileEntity> type, class_1937 level) { super(type, level); }
    @Override public AiProfile aiProfile() { return AiProfile.SHAMAN; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        launchProfileProjectile(level, this, target);
    }
}
