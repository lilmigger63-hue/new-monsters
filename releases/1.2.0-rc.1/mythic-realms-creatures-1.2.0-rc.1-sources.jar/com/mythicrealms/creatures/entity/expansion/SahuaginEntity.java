package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.CreatureKind;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1332;
import net.minecraft.class_1347;
import net.minecraft.class_1378;
import net.minecraft.class_1379;
import net.minecraft.class_1394;
import net.minecraft.class_1408;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_5757;
import net.minecraft.class_5766;
import net.minecraft.class_7;

/** Scout combat with amphibious paths and real vertical swimming, without forced surfacing. */
public final class SahuaginEntity extends ScoutProfileEntity {
    public SahuaginEntity(class_1299<? extends SahuaginEntity> type, class_1937 level) {
        super(type, level);
        field_6207 = new class_5757(this, 85, 10, 1, 1, false);
        field_6206 = new class_1332(this, 10);
        method_5941(class_7.field_18, 0);
        method_5941(class_7.field_4, 0);
    }
    @Override public CreatureKind kind() { return CreatureKind.SAHUAGIN; }
    @Override protected class_1408 method_5965(class_1937 level) {
        return new class_5766(this, level);
    }
    @Override protected void method_5959() {
        super.method_5959();
        field_6201.method_35113(goal -> goal instanceof class_1347 || goal instanceof class_1394);
        field_6201.method_6277(6, new class_1378(this, .8, 40) {
            @Override public boolean method_6264() { return method_5799() && super.method_6264(); }
            @Override public boolean method_6266() { return method_5799() && super.method_6266(); }
        });
        field_6201.method_6277(6, new class_1379(this, .8) {
            @Override public boolean method_6264() { return !method_5799() && super.method_6264(); }
            @Override public boolean method_6266() { return !method_5799() && super.method_6266(); }
        });
    }
    @Override public boolean method_6094() { return true; }
    @Override public boolean method_5675() { return false; }
    @Override public void method_5790() {
        if (!method_73183().method_8608()) method_5796(method_5799() && !method_5942().method_6357());
    }
    @Override public void method_6091(class_243 input) {
        if (method_6034() && method_5799()) {
            // SmoothSwimmingMoveControl already scales input by MOVEMENT_SPEED.
            // A fixed aquatic acceleration avoids applying that speed twice and
            // building enough momentum to orbit/overshoot path nodes.
            method_5724(.02f, input);
            method_5784(class_1313.field_6308, method_18798());
            method_18799(method_18798().method_1021(.9));
        } else {
            super.method_6091(input);
        }
    }
}
