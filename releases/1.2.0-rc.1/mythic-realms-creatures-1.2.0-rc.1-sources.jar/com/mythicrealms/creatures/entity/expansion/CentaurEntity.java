package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.CreatureKind;
import net.minecraft.class_1299;
import net.minecraft.class_1937;

public final class CentaurEntity extends ScoutProfileEntity {
    public CentaurEntity(class_1299<? extends CentaurEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.CENTAUR; }
}
