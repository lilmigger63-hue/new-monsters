package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.CreatureKind;
import net.minecraft.class_1299;
import net.minecraft.class_1937;

public final class ValkyrieEntity extends ScoutProfileEntity {
    public ValkyrieEntity(class_1299<? extends ValkyrieEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.VALKYRIE; }
}
