package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.CreatureKind;
import net.minecraft.class_1299;
import net.minecraft.class_1937;

public final class EnderDragonGirlEntity extends DemonProfileEntity {
    public EnderDragonGirlEntity(class_1299<? extends EnderDragonGirlEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.ENDER_DRAGON_GIRL; }
}
