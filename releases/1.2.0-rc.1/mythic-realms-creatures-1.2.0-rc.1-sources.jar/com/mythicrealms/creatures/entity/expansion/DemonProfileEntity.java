package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.DemonSorceressEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

/** Inherits the original DemonSorceress goals, cooperation and server combat timeline. */
public abstract class DemonProfileEntity extends DemonSorceressEntity implements ProfiledCreature {
    protected DemonProfileEntity(class_1299<? extends DemonProfileEntity> type, class_1937 level) { super(type, level); }
    @Override public AiProfile aiProfile() { return AiProfile.DEMON; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        if (method_5858(target) < 16) teleportAway(level, target);
        launchProfileProjectile(level, this, target);
    }
}
