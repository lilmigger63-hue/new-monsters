package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.GoblinScoutEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

/** Inherits the original GoblinScout goals, cooperation and server combat timeline. */
public abstract class ScoutProfileEntity extends GoblinScoutEntity implements ProfiledCreature {
    protected ScoutProfileEntity(class_1299<? extends ScoutProfileEntity> type, class_1937 level) { super(type, level); }
    @Override public AiProfile aiProfile() { return AiProfile.SCOUT; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        melee(level, target, attackRange(), 1);
    }
}
