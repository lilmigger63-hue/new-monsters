package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.CreatureProjectile;
import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_2394;
import net.minecraft.class_2398;

/** Shared capabilities; species balance remains in CreatureKind and entity attributes. */
public enum AiProfile {
    SCOUT(false, true, 0, null),
    SHAMAN(true, true, 1.1f, class_2398.field_11211),
    SLIME(true, false, 1.1f, class_2398.field_11246),
    DEMON(true, true, 1.2f, class_2398.field_11214);

    public final boolean ranged, attacksPlayers;
    public final float projectileSpeed;
    public final class_2394 combatParticle;
    AiProfile(boolean ranged, boolean attacksPlayers, float projectileSpeed, class_2394 particle) {
        this.ranged = ranged;
        this.attacksPlayers = attacksPlayers;
        this.projectileSpeed = projectileSpeed;
        this.combatParticle = particle;
    }
    public class_1299<CreatureProjectile> projectile() {
        return switch (this) {
            case SHAMAN -> ModEntities.SHAMAN_BOLT;
            case SLIME -> ModEntities.SLIME_BUBBLE;
            case DEMON -> ModEntities.DARK_BOLT;
            case SCOUT -> throw new IllegalStateException("Scout profile uses melee");
        };
    }
    public String attackAnimation() { return ranged ? "cast" : "attack"; }
}
