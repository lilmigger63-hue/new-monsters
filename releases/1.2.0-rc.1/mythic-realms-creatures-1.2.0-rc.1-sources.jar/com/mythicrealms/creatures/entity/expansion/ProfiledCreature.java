package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.CreatureKind;
import com.mythicrealms.creatures.entity.CreatureProjectile;
import com.mythicrealms.creatures.magic.SpellEffects;
import net.minecraft.class_1309;
import net.minecraft.class_3218;

/** Override profile/projectile/range hooks in one species without copying its inherited goals. */
public interface ProfiledCreature {
    CreatureKind kind();
    AiProfile aiProfile();
    default double attackRange() { return kind().range; }
    default void launchProfileProjectile(class_3218 level, class_1309 caster, class_1309 target) {
        if (caster.method_5858(target) >= attackRange() * attackRange()) return;
        var profile = aiProfile();
        CreatureProjectile.launch(profile.projectile(), caster, target, profile.projectileSpeed);
        if (profile.combatParticle != null)
            SpellEffects.particles(level, profile.combatParticle, caster.method_23317(), caster.method_23320(), caster.method_23321(), 3, .15);
    }
}
