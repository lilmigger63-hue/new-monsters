package com.mythicrealms.creatures.entity.expansion;

import com.mythicrealms.creatures.entity.SlimeMaidenEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

/** Inherits the original SlimeMaiden goals, cooperation and server combat timeline. */
public abstract class SlimeProfileEntity extends SlimeMaidenEntity implements ProfiledCreature {
    protected SlimeProfileEntity(class_1299<? extends SlimeProfileEntity> type, class_1937 level) { super(type, level); }
    @Override public AiProfile aiProfile() { return AiProfile.SLIME; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        launchProfileProjectile(level, this, target);
    }
}
