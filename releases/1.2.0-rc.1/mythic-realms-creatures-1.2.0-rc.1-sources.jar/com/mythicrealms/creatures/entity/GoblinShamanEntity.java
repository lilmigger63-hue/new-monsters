package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.world.entity.*;

public class GoblinShamanEntity extends MythicHostileEntity {
    public GoblinShamanEntity(class_1299<? extends GoblinShamanEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.GOBLIN_SHAMAN; }
    @Override public boolean ranged() { return true; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        if (method_5858(target) < 225) CreatureProjectile.launch(ModEntities.SHAMAN_BOLT, this, target, 1.1f);
    }
    @Override protected void method_5958(class_3218 level) {
        super.method_5958(level);
        if (field_6012 % 160 != 0 || attack.isWindingUp()) return;
        var wounded = level.method_8390(MythicHostileEntity.class, method_5829().method_1014(7),
            ally -> ally.method_5805() && ally.method_6032() < ally.method_6063() && method_5985().method_6369(ally));
        if (!wounded.isEmpty()) {
            var ally = wounded.getFirst(); ally.method_6025(4);
            triggerAnim("action", "cast");
            com.mythicrealms.creatures.magic.SpellEffects.particles(level,class_2398.field_11211,ally.method_23317(),ally.method_23318()+1,ally.method_23321(),6,.3);
            method_5783(class_3417.field_14858, .6f, 1.4f);
        }
    }
}
