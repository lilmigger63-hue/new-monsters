package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.ai.CreatureCombatGoal;
import com.mythicrealms.creatures.entity.combat.AttackTimeline;
import net.minecraft.world.entity.*;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.network.syncher.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animatable.processing.AnimationController;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public abstract class MythicHostileEntity extends class_1588 implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");
    private static final RawAnimation FLY=RawAnimation.begin().thenLoop("fly");
    private static final RawAnimation HOVER=RawAnimation.begin().thenLoop("hover");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("walk");
    private static final RawAnimation DEATH = RawAnimation.begin().thenPlayAndHold("death");
    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);
    public final AttackTimeline attack;
    private class_1309 committedTarget;
    private static final class_2940<Byte> VISUAL_POSE=class_2945.method_12791(MythicHostileEntity.class,class_2943.field_13319);
    @Override protected void method_5693(class_2945.class_9222 data){super.method_5693(data);data.method_56912(VISUAL_POSE,(byte)0);}
    public byte visualPose(){return field_6011.method_12789(VISUAL_POSE);}
    private void updateVisualPose(){
        byte pose=0;
        if(!attack.isWindingUp() && method_5805()){
            if(kind()==CreatureKind.MINOTAUR && busy())pose=2;
            else if(method_5968()!=null && (kind()==CreatureKind.GRAVE_KNIGHT || kind()==CreatureKind.ORC_WARRIOR) && method_5858(method_5968())<20)pose=1;
            else if(kind()==CreatureKind.GOBLIN_SCOUT && method_5968()!=null && field_6012%60<14 && method_5858(method_5968())>=9 && method_5858(method_5968())<=49)pose=3;
        }
        field_6011.method_12778(VISUAL_POSE,pose);
    }

    protected MythicHostileEntity(class_1299<? extends MythicHostileEntity> type, class_1937 level) {
        super(type, level);
        attack = new AttackTimeline(kind().windup, kind().recovery);
        field_6194 = kind().width >= 1.3 ? 12 : 5;
    }
    public abstract CreatureKind kind();
    public abstract void performAttack(class_3218 level, class_1309 target);
    public boolean reposition(class_1309 target) { return false; }
    public boolean ranged() { return false; }
    public boolean busy() { return false; }
    protected String attackAnimation() { return ranged() ? "cast" : "attack"; }
    public boolean tryAttack(class_1309 target) {
        if (!attack.tryStart()) return false;
        committedTarget = target;
        method_5942().method_6340();
        triggerAnim("action", attackAnimation());
        if(method_73183() instanceof class_3218 server)com.mythicrealms.creatures.magic.SpellEffects.telegraph(server,this,kind(),target);
        method_5783(switch(kind()) {
            case STONE_TROLL, FROST_ELEMENTAL -> class_3417.field_15026;
            case GOBLIN_SHAMAN, SHADOW_WRAITH, DEMON_SORCERESS -> class_3417.field_14908;
            case FLAME_IMP -> class_3417.field_14970;
            case CAVE_BASILISK, CRYSTAL_SPIDER -> class_3417.field_15170;
            case HARPY -> class_3417.field_14869;
            default -> class_3417.field_14706;
        }, .7f, .6f);
        return true;
    }
    @Override protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(2, new CreatureCombatGoal(this));
        field_6201.method_6277(6, new class_1394(this, .8));
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 8));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1399(this));
        field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }
    @Override protected void method_5958(class_3218 level) {
        super.method_5958(level);
        updateVisualPose();
        if(field_6012%12==0) {
            net.minecraft.class_2394 particle=switch(kind()) {
                case GOBLIN_SHAMAN -> net.minecraft.class_2398.field_11211;
                case CRYSTAL_SPIDER -> net.minecraft.class_2398.field_11207;
                case SHADOW_WRAITH -> net.minecraft.class_2398.field_11251;
                case FLAME_IMP -> net.minecraft.class_2398.field_11240;
                case FROST_ELEMENTAL -> net.minecraft.class_2398.field_28013;
                case DEMON_SORCERESS -> net.minecraft.class_2398.field_11249;
                default -> null;
            };
            if(particle!=null)com.mythicrealms.creatures.magic.SpellEffects.particles(level,particle,method_23317(),method_23318()+method_17682()*.5,method_23321(),2,.25);
        }
        if (committedTarget != null && (!committedTarget.method_5805() || !method_5805())) {
            attack.cancel(); committedTarget = null;
        }
        if (attack.tick()) {
            class_1309 target = committedTarget;
            committedTarget = null;
            if (target != null && target.method_5805() && method_5985().method_6369(target)) performAttack(level, target);
        }
    }
    public void interruptAttack() { attack.cancel(); committedTarget = null; }
    public boolean areaVictim(class_1309 candidate, class_1309 primaryTarget) {
        if (!candidate.method_5805() || candidate == this || method_5722(candidate)) return false;
        if (candidate instanceof class_1657 player && (player.method_68878() || player.method_7325())) return false;
        return candidate == primaryTarget || candidate instanceof class_1657;
    }
    public void melee(class_3218 level, class_1309 target, double reach, double multiplier) {
        if (target.method_5805() && method_5858(target) <= reach * reach && method_5985().method_6369(target)) {
            target.method_64397(level, method_48923().method_48812(this),
                (float)(method_45325(net.minecraft.class_5134.field_23721) * multiplier));
        }
    }
    @Override protected class_3414 method_5994() {
        return switch(kind()) {
            case CAVE_BASILISK, CRYSTAL_SPIDER -> class_3417.field_15170;
            case GRAVE_KNIGHT -> class_3417.field_15200;
            case FROST_ELEMENTAL -> class_3417.field_14655;
            case HARPY -> class_3417.field_14813;
            case DEMON_SORCERESS -> class_3417.field_14736;
            default -> class_3417.field_14976;
        };
    }
    @Override public boolean method_64397(class_3218 level,class_1282 source,float damage) {
        boolean hit=super.method_64397(level,source,damage);
        if(hit && method_5805() && !attack.isWindingUp())triggerAnim("action","hurt");
        return hit;
    }
    @Override protected class_3414 method_6011(class_1282 source) { return class_3417.field_15007; }
    @Override protected class_3414 method_6002() { return class_3417.field_15146; }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<MythicHostileEntity>("locomotion",5,test -> {
            var mob=test.animatable();
            if(mob.method_29504())return test.setAndContinue(DEATH);
            String state=mob instanceof com.mythicrealms.creatures.entity.expansion.SahuaginEntity && mob.method_5799()
                ?(test.isMoving()?"swim":"idle_swim"):
                mob instanceof AerialHostileEntity && !mob.method_24828()?(test.isMoving()?"fly":"hover"):
                test.isMoving()?(mob.method_18798().method_37268()>.01?"run":"walk"):
                mob instanceof DemonSorceressEntity?"levitate":"idle";
            return test.setAndContinue(MythicCreature.loop(state));
        }));
        controllers.add(new AnimationController<MythicHostileEntity>("posture",4,test -> {
            byte pose=test.animatable().visualPose();
            return pose==0 || test.animatable().method_29504()?PlayState.STOP:
                test.setAndContinue(MythicCreature.loop(pose==1?"guard":pose==2?"charge":"sneak"));
        }));
        var action=new AnimationController<MythicHostileEntity>("action", 2, test -> PlayState.STOP)
            .triggerableAnim("attack", RawAnimation.begin().thenPlay("attack"))
            .triggerableAnim("cast", RawAnimation.begin().thenPlay("cast"))
            .triggerableAnim("hurt", RawAnimation.begin().thenPlay("hurt"));
        if(kind()==CreatureKind.GRAVE_KNIGHT)action.triggerableAnim("attack_two",RawAnimation.begin().thenPlay("attack_two"));
        if(kind()==CreatureKind.GRAVE_KNIGHT || kind()==CreatureKind.STONE_TROLL)action.triggerableAnim("heavy",RawAnimation.begin().thenPlay("heavy"));
        if(kind()==CreatureKind.STONE_TROLL)action.triggerableAnim("throw",RawAnimation.begin().thenPlay("throw"));
        if(kind()==CreatureKind.HARPY)action.triggerableAnim("swoop",RawAnimation.begin().thenPlay("swoop"));
        if(this instanceof DemonSorceressEntity)action.triggerableAnim("teleport",RawAnimation.begin().thenPlay("teleport"));
        controllers.add(action);
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return animationCache; }
}
