package com.mythicrealms.creatures.client;

import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;
import software.bernie.geckolib.animatable.GeoEntity;
import com.mythicrealms.creatures.entity.mount.MythicMountEntity;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.constant.dataticket.DataTicket;
import com.mythicrealms.creatures.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_10042;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_7923;
import net.minecraft.class_953;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

public final class MythicRealmsClient implements ClientModInitializer {
    // Only species whose mapped UV faces contribute emissive pixels need a second mesh pass.
    private static final java.util.Set<String> EMISSIVE_SPECIES = java.util.Set.of(
        "stone_troll", "goblin_shaman", "ancient_treant", "forest_dryad", "cave_basilisk", "crystal_spider", "shadow_wraith", "grave_knight", "flame_imp", "frost_elemental", "moon_stag", "harpy", "demon_sorceress", "ender_dragon_girl", "vampire", "valkyrie", "fox_spirit_girl", "anubis", "cyclops", "dhampir", "succubus");

    @Override public void onInitializeClient() {
        register(ModEntities.GOBLIN_SCOUT, .35f);
        register(ModEntities.GOBLIN_SHAMAN, .35f);
        register(ModEntities.ORC_WARRIOR, .5f);
        register(ModEntities.MINOTAUR, .75f);
        register(ModEntities.STONE_TROLL, .9f);
        register(ModEntities.ANCIENT_TREANT,1.1f);
        register(ModEntities.FOREST_DRYAD,.35f);
        register(ModEntities.GRIFFIN,.8f);
        register(ModEntities.DIRE_WOLF,.6f);
        register(ModEntities.WILD_WYVERN,.95f);
        register(ModEntities.CAVE_BASILISK,.6f);
        register(ModEntities.CRYSTAL_SPIDER,.7f);
        register(ModEntities.SHADOW_WRAITH,.35f);
        register(ModEntities.GRAVE_KNIGHT,.4f);
        register(ModEntities.FLAME_IMP,.25f);
        register(ModEntities.FROST_ELEMENTAL,.55f);
        register(ModEntities.MOON_STAG,.55f);
        register(ModEntities.SLIME_MAIDEN,.4f);
        register(ModEntities.HARPY,.45f);
        register(ModEntities.DEMON_SORCERESS,.35f);
        register(ModEntities.ENDER_DRAGON_GIRL,0.45f);
        register(ModEntities.VAMPIRE,0.35f);
        register(ModEntities.HOLSTAURUS,0.4f);
        register(ModEntities.CENTAUR,0.65f);
        register(ModEntities.SAHUAGIN,0.35f);
        register(ModEntities.VALKYRIE,0.4f);
        register(ModEntities.FOX_SPIRIT_GIRL,0.4f);
        register(ModEntities.ANUBIS,0.35f);
        register(ModEntities.KOBOLD,0.3f);
        register(ModEntities.CYCLOPS,0.45f);
        register(ModEntities.DHAMPIR,0.35f);
        register(ModEntities.SUCCUBUS,0.4f);
        register(ModEntities.WERECAT,0.35f);
        EntityRendererRegistry.register(ModEntities.CRYSTAL_BOLT, context -> new class_953<>(context,.65f,true));
        EntityRendererRegistry.register(ModEntities.DARK_BOLT, context -> new class_953<>(context,.7f,true));
        EntityRendererRegistry.register(ModEntities.FIRE_BOLT, context -> new class_953<>(context,.6f,true));
        EntityRendererRegistry.register(ModEntities.ICE_SPIKE, context -> new class_953<>(context,.8f,true));
        EntityRendererRegistry.register(ModEntities.FEATHER_BOLT, context -> new class_953<>(context,.8f,false));
        EntityRendererRegistry.register(ModEntities.SLIME_BUBBLE, context -> new class_953<>(context,.9f,false));
        EntityRendererRegistry.register(ModEntities.WEB_TRAP, context -> new class_953<>(context,1.5f,false));
        EntityRendererRegistry.register(ModEntities.ROOT_SHARD, context -> new class_953<>(context, 1.2f, false));
        EntityRendererRegistry.register(ModEntities.VINE_SEED, context -> new class_953<>(context, .7f, true));
        EntityRendererRegistry.register(ModEntities.POISON_BREATH, context -> new class_953<>(context, .8f, true));
        EntityRendererRegistry.register(ModEntities.SHAMAN_BOLT, context -> new class_953<>(context, .65f, true));
        EntityRendererRegistry.register(ModEntities.TROLL_BOULDER, context -> new class_953<>(context, 1.8f, false));
    }
    private static <T extends class_1308 & GeoEntity> void register(class_1299<T> type, float shadow) {
        EntityRendererRegistry.register(type, context -> new CreatureRenderer<>(context, type, shadow));
    }
    private static final class CreatureModel<T extends class_1308 & GeoEntity> extends DefaultedEntityGeoModel<T> {
        private static final DataTicket<Boolean> TAMED=DataTicket.create("mythic_mount_tamed",Boolean.class);
        private static final DataTicket<Boolean> RARE=DataTicket.create("mythic_mount_rare",Boolean.class);
        private final class_2960 texture, tamedTexture, rareTexture;
        CreatureModel(class_1299<T> type){
            super(class_7923.field_41177.method_10221(type));
            var id=class_7923.field_41177.method_10221(type);
            String path="textures/entity/"+id.method_12832();
            texture=id.method_45136(path+".png");
            tamedTexture=id.method_45136(path+"_tamed.png");
            rareTexture=id.method_45136(path+"_rare.png");
        }
        @Override public void addAdditionalStateData(T entity,GeoRenderState state){
            super.addAdditionalStateData(entity,state);
            state.addGeckolibData(TAMED,entity instanceof MythicMountEntity mount && mount.method_6181());
            state.addGeckolibData(RARE,entity instanceof MythicMountEntity mount && mount.isRareVariant());
        }
        @Override public class_2960 getTextureResource(GeoRenderState state){
            return state.getOrDefaultGeckolibData(TAMED,false)?tamedTexture:
                state.getOrDefaultGeckolibData(RARE,false)?rareTexture:texture;
        }
    }
    private static final class CreatureRenderer<T extends class_1308 & GeoEntity, R extends class_10042 & GeoRenderState>
            extends GeoEntityRenderer<T, R> {
        private final boolean translucent;
        CreatureRenderer(class_5617.class_5618 context, class_1299<T> type, float shadow) {
            super(context, new CreatureModel<T>(type)); this.field_4673 = shadow;
            String id=class_7923.field_41177.method_10221(type).method_12832();
            translucent=id.equals("shadow_wraith") || id.equals("slime_maiden");
            if (EMISSIVE_SPECIES.contains(id))
                withRenderLayer(new AutoGlowingGeoLayer<>(this));
        }
        @Override public class_1921 getRenderType(R state,class_2960 texture) {
            return translucent && !state.field_53333 ? class_1921.method_23580(texture) : super.getRenderType(state,texture);
        }
        // The model supplies its own death pose; avoid applying a second vanilla roll.
        @Override protected float getDeathMaxRotation(GeoRenderState state) { return 0; }
    }
}
