package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.world.entity.*;

public final class StoneTrollEntity extends MythicHostileEntity {
    public StoneTrollEntity(class_1299<? extends StoneTrollEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.STONE_TROLL; }
    @Override public boolean ranged() { return true; }
    @Override public void performAttack(class_3218 level, class_1309 target) {
        if (method_5858(target) < 25) {
            for (class_1309 player : level.method_8390(class_1309.class, method_5829().method_1014(2.8), p -> areaVictim(p, target))) {
                melee(level, player, 4.5, 1);
                player.method_6005(.9, method_23317() - player.method_23317(), method_23321() - player.method_23321());
            }
            com.mythicrealms.creatures.magic.SpellEffects.particles(level,class_2398.field_11204,method_23317(),method_23318()+.2,method_23321(),16,1.1);
            method_5783(class_3417.field_15152.comp_349(), .5f, .6f);
        } else if (method_5858(target) < 256) CreatureProjectile.launch(ModEntities.TROLL_BOULDER, this, target, 1.2f);
    }
}
