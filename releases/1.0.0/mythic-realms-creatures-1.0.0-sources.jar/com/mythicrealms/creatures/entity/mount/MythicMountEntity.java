package com.mythicrealms.creatures.entity.mount;

import com.mythicrealms.creatures.config.CreatureConfig;
import com.mythicrealms.creatures.entity.*;
import com.mythicrealms.creatures.entity.ai.GuardianCombatGoal;
import com.mythicrealms.creatures.entity.combat.AttackTimeline;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1321;
import net.minecraft.class_1331;
import net.minecraft.class_1347;
import net.minecraft.class_1350;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1386;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1403;
import net.minecraft.class_1406;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_4048;
import net.minecraft.class_5134;
import net.minecraft.class_5275;
import net.minecraft.network.syncher.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.navigation.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.storage.*;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Owner-persistent mounts. Vanilla Player Input packets are the only source of rider controls. */
public abstract class MythicMountEntity extends class_1321 implements CreatureCombatant {
    private static final class_2940<Boolean> SADDLED=class_2945.method_12791(MythicMountEntity.class,class_2943.field_13323);
    private static final class_2940<Boolean> FLYING=class_2945.method_12791(MythicMountEntity.class,class_2943.field_13323);
    private static final class_2940<Boolean> RARE=class_2945.method_12791(MythicMountEntity.class,class_2943.field_13323);
    private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
    private final AttackTimeline attack;
    private class_1309 pending;

    protected MythicMountEntity(class_1299<? extends MythicMountEntity> type,class_1937 level){
        super(type,level);attack=new AttackTimeline(kind().windup,kind().recovery);
        if(canFly())field_6207=new class_1331(this,12,false);
    }
    public boolean canFly(){return kind()==CreatureKind.GRIFFIN || kind()==CreatureKind.WILD_WYVERN;}
    public abstract class_1792 tamingItem();
    public class_1792 healingItem(){return tamingItem();}
    public boolean isTamingFood(class_1799 stack){
        var item=switch(kind()){
            case GRIFFIN -> com.mythicrealms.creatures.registry.ModItems.SUNSEED_BISCUIT;
            case DIRE_WOLF -> com.mythicrealms.creatures.registry.ModItems.HEARTY_MEAT;
            case WILD_WYVERN -> com.mythicrealms.creatures.registry.ModItems.VENOMOUS_MORSEL;
            case MOON_STAG -> com.mythicrealms.creatures.registry.ModItems.MOONBLOSSOM;
            default -> tamingItem();
        };
        return stack.method_31574(tamingItem()) || stack.method_31574(item);
    }
    public boolean isHealingFood(class_1799 stack){return stack.method_31574(healingItem()) || isTamingFood(stack) && !stack.method_31574(class_1802.field_8606);}
    public boolean acceptedSaddle(class_1799 stack){return stack.method_31574(class_1802.field_8175)
        || kind()==CreatureKind.GRIFFIN && stack.method_31574(com.mythicrealms.creatures.registry.ModItems.GRIFFIN_SADDLE)
        || kind()==CreatureKind.WILD_WYVERN && stack.method_31574(com.mythicrealms.creatures.registry.ModItems.WYVERN_HARNESS);}
    public boolean canBeTamed(){return true;}
    public boolean isFlying(){return field_6011.method_12789(FLYING);}
    public void setFlying(boolean flying){field_6011.method_12778(FLYING,canFly() && flying);method_5875(canFly() && flying);}
    public boolean method_66672(){return field_6011.method_12789(SADDLED);}
    public void setSaddled(boolean saddled){field_6011.method_12778(SADDLED,saddled);}
    public boolean isRareVariant(){return field_6011.method_12789(RARE);}
    public void setRareVariant(boolean rare){field_6011.method_12778(RARE,kind()==CreatureKind.WILD_WYVERN && rare);}
    @Override protected void method_5693(class_2945.class_9222 builder){
        super.method_5693(builder);builder.method_56912(SADDLED,false);builder.method_56912(FLYING,false);builder.method_56912(RARE,false);
    }
    @Override protected void method_5652(class_11372 output){
        super.method_5652(output);output.method_71472("Saddled",method_66672());output.method_71472("RareVariant",isRareVariant());
    }
    @Override protected void method_5749(class_11368 input){
        super.method_5749(input);setSaddled(input.method_71433("Saddled",false));
        setRareVariant(input.method_71433("RareVariant",false));method_6179(method_24345());setFlying(false);
    }
    @Override protected class_1408 method_5965(class_1937 level){
        if(!canFly())return super.method_5965(level);
        var nav=new class_1407(this,level);nav.method_70687(false);nav.method_6354(true);return nav;
    }
    @Override protected boolean method_60716(){return canFly();}
    @Override protected void method_5959(){
        field_6201.method_6277(0,new class_1347(this));
        field_6201.method_6277(1,new class_1386(this));
        field_6201.method_6277(2,new GuardianCombatGoal(this));
        field_6201.method_6277(3,new class_1350(this,1.05,6,2){
            @Override public boolean method_6264(){return !method_5782() && super.method_6264();}
            @Override public boolean method_6266(){return !method_5782() && super.method_6266();}
        });
        field_6201.method_6277(4,new class_1391(this,1.0,this::isTamingFood,false));
        if(canFly())field_6201.method_6277(5,new MountAirWanderGoal(this));
        else field_6201.method_6277(6,new class_1394(this,.8));
        field_6201.method_6277(7,new class_1361(this,class_1657.class,8));
        field_6201.method_6277(8,new class_1376(this));
        field_6185.method_6277(1,new class_1403(this));
        field_6185.method_6277(2,new class_1406(this));
        field_6185.method_6277(3,new class_1399(this));
    }
    @Override public boolean canEngage(){return method_5805() && !method_24345() && !method_5782();}
    @Override public boolean method_18395(class_1309 target){
        if(method_6171(target) || target instanceof class_1657 p && (p.method_68878() || p.method_7325()))return false;
        if(target instanceof class_1321 ally && method_66287()!=null && ally.method_66287()!=null
            && method_66287().method_66263().equals(ally.method_66287().method_66263()))return false;
        return super.method_18395(target);
    }
    @Override public AttackTimeline combatTimeline(){return attack;}
    @Override public boolean beginAttack(class_1309 target){
        if(!canEngage() || !method_18395(target) || !attack.tryStart())return false;
        pending=target;triggerAnim("action","attack");method_5783(class_3417.field_14706,.6f,.8f);return true;
    }
    @Override public void interruptAttack(){attack.cancel();pending=null;}
    public void performAttack(class_3218 level,class_1309 target){
        if(method_18395(target) && method_5858(target)<kind().range*kind().range && method_5985().method_6369(target))
            target.method_64397(level,method_48923().method_48812(this),(float)method_45325(class_5134.field_23721));
    }
    @Override protected void method_5958(class_3218 level){
        super.method_5958(level);
        if(isFlying() && field_6012%12==0)
            com.mythicrealms.creatures.magic.SpellEffects.particles(level,kind()==CreatureKind.GRIFFIN?net.minecraft.class_2398.field_23956:net.minecraft.class_2398.field_11234,method_23317(),method_23318()+.5,method_23321(),2,.5);
        if(!canEngage() || pending!=null && (!pending.method_5805() || !method_18395(pending)))interruptAttack();
        if(attack.tick()){
            var target=pending;pending=null;
            if(target!=null && method_18395(target) && method_5985().method_6369(target))performAttack(level,target);
        }
        if(method_5782()){method_5942().method_6340();method_5980(null);}
        if(canFly() && method_6181() && !method_24345() && !method_5782() && method_35057()!=null && method_5858(method_35057())>36)setFlying(true);
        if(canFly() && method_24828() && !method_5782() && method_5942().method_6357())setFlying(false);
    }
    @Override public boolean method_6481(class_1799 stack){return isHealingFood(stack);}
    private void consume(class_1799 stack,class_1657 player){if(!player.method_31549().field_7477)stack.method_7934(1);}
    @Override public class_1269 method_5992(class_1657 player,class_1268 hand){
        if(hand!=class_1268.field_5808)return class_1269.field_5811;
        class_1799 stack=player.method_5998(hand);
        if(!method_6181() && isTamingFood(stack)){
            if(method_73183().method_8608())return class_1269.field_5812;
            if(!canBeTamed()){
                player.method_7353(class_2561.method_43471("message.mythic_realms_creatures.wyvern_wild"),true);
                return class_1269.field_52422;
            }
            consume(stack,player);
            if(method_59922().method_43048(CreatureConfig.INSTANCE.tamingDifficulty)==0){
                method_6174(player);method_6173(true,true);method_5980(null);interruptAttack();method_5942().method_6340();
                method_73183().method_8421(this,(byte)7);triggerAnim("action","tame");
            } else method_73183().method_8421(this,(byte)6);
            return class_1269.field_52422;
        }
        if(method_6181() && method_6171(player)){
            if(isHealingFood(stack)){
                if(method_73183().method_8608())return class_1269.field_5812;
                if(method_6032()<method_6063()){consume(stack,player);method_6025(6);method_5783(class_3417.field_20614.comp_349(),1,1);}
                return class_1269.field_52422;
            }
            if(acceptedSaddle(stack) && !method_66672()){
                if(method_73183().method_8608())return class_1269.field_5812;
                setSaddled(true);consume(stack,player);method_5783(class_3417.field_14704.comp_349(),.7f,1);return class_1269.field_52422;
            }
            if(player.method_5715() && !method_5782()){
                if(method_73183().method_8608())return class_1269.field_5812;
                if(isFlying() && !method_24828())player.method_7353(class_2561.method_43471("message.mythic_realms_creatures.land_first"),true);
                else{
                    method_24346(!method_24345());method_6179(method_24345());method_5980(null);interruptAttack();method_5942().method_6340();
                    player.method_7353(class_2561.method_43471(method_24345()?"message.mythic_realms_creatures.stay":"message.mythic_realms_creatures.follow"),true);
                }
                return class_1269.field_52422;
            }
            if(stack.method_7960() && !method_6109() && !method_24345()){
                if(method_73183().method_8608())return class_1269.field_5812;
                if(method_66672()){interruptAttack();player.method_5804(this);}else player.method_7353(class_2561.method_43471("message.mythic_realms_creatures.saddle_required"),true);
                return class_1269.field_52422;
            }
        }
        return super.method_5992(player,hand);
    }
    @Override public class_1296 method_5613(class_3218 level,class_1296 mate){
        var child=(MythicMountEntity)method_5864().method_5883(level,class_3730.field_16466);
        if(child!=null && mate instanceof MythicMountEntity other && method_6181() && other.method_6181()
            && method_66287()!=null && other.method_66287()!=null
            && method_66287().method_66263().equals(other.method_66287().method_66263())){
            child.method_66288(method_66287());child.method_6173(true,true);child.setRareVariant(isRareVariant() && other.isRareVariant());
        }
        return child;
    }
    @Override public class_1309 method_5642(){
        return method_31483() instanceof class_1657 player && method_6181() && method_6171(player)
            && method_66672() && !method_24345() && method_5805()?player:null;
    }
    @Override protected boolean method_5818(class_1297 passenger){
        return passenger instanceof class_1657 player && method_6171(player) && method_66672() && !method_6109() && !method_24345() && method_5685().isEmpty();
    }
    // Server-simulated mounts reject client vehicle-position authority; vanilla input booleans are sufficient.
    @Override public boolean method_65038(){return false;}
    @Override protected boolean method_66248(){return false;}
    @Override protected class_243 method_49482(class_1657 player,class_243 input){return class_243.field_1353;}
    @Override protected float method_49485(class_1657 player){return (float)(kind().speed*CreatureConfig.INSTANCE.mountSpeedMultiplier);}
    @Override public boolean method_70987(){return isFlying();}
    @Override public void method_6091(class_243 input){
        if(method_6172()){method_5942().method_6340();super.method_6091(class_243.field_1353);return;}
        if(method_5642() instanceof class_3222 rider){
            var controls=rider.method_63562();
            double forward=(controls.comp_3159()?1:0)-(controls.comp_3160()?1:0);
            double strafe=(controls.comp_3161()?1:0)-(controls.comp_3162()?1:0);
            int vertical=(controls.comp_3163()?1:0)-(controls.comp_3165()?1:0);
            method_36456(rider.method_36454());field_6241=method_36454();field_6283=method_36454();method_36457(rider.method_36455()*.35f);
            if(canFly() && controls.comp_3163())setFlying(true);
            if(isFlying()){
                if(method_24828() && vertical<=0){setFlying(false);}else{
                    method_5875(true);field_6017=0;
                    var v=method_18798();
                    var motion=FlightMotion.step(new FlightMotion.Motion(v.field_1352,v.field_1351,v.field_1350),method_36454(),forward,strafe,vertical,
                        .55*CreatureConfig.INSTANCE.flightSpeedMultiplier,method_23318()<method_73183().method_31600()-3);
                    class_243 velocity=new class_243(motion.x(),motion.y(),motion.z());
                    if(!method_73183().method_22340(class_2338.method_49638(method_73189().method_1019(velocity))))velocity=class_243.field_1353;
                    method_18799(velocity);method_5784(class_1313.field_6308,velocity);method_29242(false);return;
                }
            }
            method_5875(false);method_6125(method_49485(rider));
            if(controls.comp_3163() && method_24828())method_18800(method_18798().field_1352,.42,method_18798().field_1350);
            super.method_6091(new class_243(strafe*.5,0,forward*(forward<0?.3:1)));return;
        }
        if(isFlying() && method_66247()){
            method_5875(true);field_6017=0;
            method_5724(.06f,input);
            class_243 velocity=method_18798();
            if(method_5942().method_6357() && method_5968()==null)velocity=new class_243(velocity.field_1352*.8,-.1,velocity.field_1350*.8);
            if(velocity.method_1033()>.6)velocity=velocity.method_1029().method_1021(.6);
            if(method_23318()>method_73183().method_31600()-3)velocity=new class_243(velocity.field_1352,Math.min(0,velocity.field_1351),velocity.field_1350);
            if(!method_73183().method_22340(class_2338.method_49638(method_73189().method_1019(velocity))))velocity=class_243.field_1353;
            method_18799(velocity);method_5784(class_1313.field_6308,velocity);method_18799(velocity.method_1021(.85));method_29242(false);
        }else{if(!isFlying())method_5875(false);super.method_6091(input);}
    }
    @Override protected class_243 method_52533(class_1297 passenger,class_4048 dimensions,float scale){
        return new class_243(0,method_17682()*(kind()==CreatureKind.DIRE_WOLF?.72:.66),0);
    }
    @Override public class_243 method_24829(class_1309 passenger){
        if(method_24828())for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){
            if(x==0 && z==0)continue;
            var pos=method_24515().method_10069(x,0,z);
            if(!method_73183().method_22340(pos))continue;
            class_243 safe=class_5275.method_30769(passenger.method_5864(),method_73183(),pos,true);
            if(safe!=null)return safe;
        }
        return super.method_24829(passenger);
    }
    @Override public boolean method_5747(double distance,float multiplier,class_1282 source){return !canFly() && super.method_5747(distance,multiplier,source);}
    @Override public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
    @Override public boolean method_64397(class_3218 level,net.minecraft.class_1282 source,float damage){
        boolean hit=super.method_64397(level,source,damage);
        if(hit && method_5805() && !combatTimeline().isWindingUp())triggerAnim("action","hurt");
        return hit;
    }

}
