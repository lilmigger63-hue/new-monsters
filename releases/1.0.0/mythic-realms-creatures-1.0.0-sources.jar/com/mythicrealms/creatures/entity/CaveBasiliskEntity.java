package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.magic.SpellEffects;
import net.minecraft.world.entity.*;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.world.effect.*;

public final class CaveBasiliskEntity extends MythicHostileEntity {
    public CaveBasiliskEntity(class_1299<? extends CaveBasiliskEntity> type,class_1937 level){super(type,level);}
    @Override public CreatureKind kind(){return CreatureKind.CAVE_BASILISK;}
    @Override public boolean ranged(){return true;}
    @Override public void performAttack(class_3218 level,class_1309 target){
        if(method_5858(target)>81 || !method_5985().method_6369(target))return;
        boolean hurt=target.method_64397(level,method_48923().method_48812(this),(float)method_45325(net.minecraft.class_5134.field_23721));
        if(hurt){SpellEffects.slow(target,65,3);target.method_6092(new class_1293(class_1294.field_5901,65,1));}
        SpellEffects.particles(level,class_2398.field_22247,target.method_23317(),target.method_23320(),target.method_23321(),10,.3);
    }
}
