package com.mythicrealms.creatures.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;

public final class GoblinScoutEntity extends MythicHostileEntity {
    public GoblinScoutEntity(class_1299<? extends GoblinScoutEntity> type, class_1937 level) { super(type, level); }
    @Override public CreatureKind kind() { return CreatureKind.GOBLIN_SCOUT; }
    @Override public boolean reposition(class_1309 target) {
        if (method_5858(target) < 9 || method_5858(target) > 49 || field_6012 % 60 >= 14) return false;
        if (field_6012 % 7 == 0) {
            class_243 offset = method_73189().method_1020(target.method_73189()).method_1029();
            double side = (method_5628() & 1) == 0 ? 1 : -1;
            class_243 point = target.method_73189().method_1031(-offset.field_1350 * 2.5 * side, 0, offset.field_1352 * 2.5 * side);
            method_5942().method_6337(point.field_1352, point.field_1351, point.field_1350, 1.2);
        }
        return true;
    }
    @Override public void performAttack(class_3218 level, class_1309 target) { melee(level, target, 2.1, 1); }
}
