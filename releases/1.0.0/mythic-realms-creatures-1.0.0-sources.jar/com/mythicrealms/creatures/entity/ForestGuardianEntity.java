package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.ai.GuardianCombatGoal;
import com.mythicrealms.creatures.entity.combat.AttackTimeline;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.util.GeckoLibUtil;

public abstract class ForestGuardianEntity extends class_1314 implements CreatureCombatant {
    private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
    private final AttackTimeline attack;
    private class_1309 pending;
    protected ForestGuardianEntity(class_1299<? extends ForestGuardianEntity> type,class_1937 level) {
        super(type,level);attack=new AttackTimeline(kind().windup,kind().recovery);field_6194=6;
    }
    @Override protected void method_5959() {
        field_6201.method_6277(0,new class_1347(this));
        field_6201.method_6277(2,new GuardianCombatGoal(this));
        field_6201.method_6277(6,new class_1394(this,.7));
        field_6201.method_6277(7,new class_1361(this,class_1657.class,8));
        field_6201.method_6277(8,new class_1376(this));
        field_6185.method_6277(1,new class_1399(this));
        field_6185.method_6277(2,new class_1400<>(this,class_1588.class,true));
    }
    @Override public boolean method_18395(class_1309 target) { return !(target instanceof ForestGuardianEntity) && super.method_18395(target); }
    @Override public AttackTimeline combatTimeline() { return attack; }
    @Override public boolean beginAttack(class_1309 target) {
        if (!method_18395(target) || !attack.tryStart())return false;
        pending=target;triggerAnim("action","attack");method_5783(class_3417.field_14908,.5f,.7f);return true;
    }
    @Override public void interruptAttack() { attack.cancel();pending=null; }
    @Override protected void method_5958(class_3218 level) {
        super.method_5958(level);
        if(kind()==CreatureKind.ANCIENT_TREANT && field_6012%20==0)
            com.mythicrealms.creatures.magic.SpellEffects.particles(level,net.minecraft.class_2398.field_11211,method_23317(),method_23318()+method_17682()*.7,method_23321(),2,.6);
        if(pending!=null && (!pending.method_5805() || !method_18395(pending)))interruptAttack();
        if(attack.tick()) {
            var target=pending;pending=null;
            if(target!=null && method_5858(target)<kind().range*kind().range && method_5985().method_6369(target))performAttack(level,target);
        }
    }
    public abstract void performAttack(class_3218 level,class_1309 target);
    @Override protected class_3414 method_5994(){return class_3417.field_28559;}
    @Override protected class_3414 method_6011(class_1282 source){return class_3417.field_15215;}
    @Override protected class_3414 method_6002(){return class_3417.field_15215;}
    @Override public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
    @Override public boolean method_64397(class_3218 level,net.minecraft.class_1282 source,float damage){
        boolean hit=super.method_64397(level,source,damage);
        if(hit && method_5805() && !combatTimeline().isWindingUp())triggerAnim("action","hurt");
        return hit;
    }

}
