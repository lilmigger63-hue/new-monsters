package com.mythicrealms.creatures.magic;

import com.mythicrealms.creatures.config.CreatureConfig;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2394;
import net.minecraft.class_3218;
import net.minecraft.world.effect.*;

public final class SpellEffects {
    private SpellEffects() { }
    public static void particles(class_3218 level,class_2394 particle,double x,double y,double z,int count,double spread){
        int amount=Math.clamp((int)Math.round(count*CreatureConfig.INSTANCE.magicParticleIntensity),0,64);
        if(amount>0)level.method_65096(particle,x,y,z,amount,spread,spread,spread,.02);
    }
    public static void slow(class_1309 target,int ticks,int strength){target.method_6092(new class_1293(class_1294.field_5909,ticks,strength));}
}
