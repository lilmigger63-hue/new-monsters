package com.mythicrealms.creatures.client;

import com.mythicrealms.creatures.entity.MythicHostileEntity;
import com.mythicrealms.creatures.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_10042;
import net.minecraft.class_1299;
import net.minecraft.class_5617;
import net.minecraft.class_953;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

public final class MythicRealmsClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        register(ModEntities.GOBLIN_SCOUT, .35f);
        register(ModEntities.GOBLIN_SHAMAN, .35f);
        register(ModEntities.ORC_WARRIOR, .5f);
        register(ModEntities.MINOTAUR, .75f);
        register(ModEntities.STONE_TROLL, .9f);
        EntityRendererRegistry.register(ModEntities.SHAMAN_BOLT, context -> new class_953<>(context, .65f, true));
        EntityRendererRegistry.register(ModEntities.TROLL_BOULDER, context -> new class_953<>(context, 1.8f, false));
    }
    private static <T extends MythicHostileEntity> void register(class_1299<T> type, float shadow) {
        EntityRendererRegistry.register(type, context -> new CreatureRenderer<>(context, type, shadow));
    }
    private static final class CreatureRenderer<T extends MythicHostileEntity, R extends class_10042 & GeoRenderState>
            extends GeoEntityRenderer<T, R> {
        CreatureRenderer(class_5617.class_5618 context, class_1299<T> type, float shadow) {
            super(context, type); this.field_4673 = shadow;
        }
        // The model supplies its own death pose; avoid applying a second vanilla roll.
        @Override protected float getDeathMaxRotation(GeoRenderState state) { return 0; }
    }
}
