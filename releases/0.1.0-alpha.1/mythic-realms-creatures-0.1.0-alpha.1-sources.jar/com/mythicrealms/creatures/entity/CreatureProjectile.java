package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.registry.ModEntities;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3857;
import net.minecraft.class_3966;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.*;

public final class CreatureProjectile extends class_3857 {
    public CreatureProjectile(class_1299<? extends CreatureProjectile> type, class_1937 level) { super(type, level); }
    @Override protected class_1792 method_16942() { return method_5864() == ModEntities.TROLL_BOULDER ? class_1802.field_20412 : class_1802.field_8777; }
    public static void launch(class_1299<CreatureProjectile> type, MythicHostileEntity caster, class_1309 target, float speed) {
        CreatureProjectile bolt = new CreatureProjectile(type, caster.method_73183());
        bolt.method_7432(caster);
        bolt.method_5814(caster.method_23317(), caster.method_23320() - .15, caster.method_23321());
        class_243 delta = target.method_33571().method_1020(bolt.method_73189());
        bolt.method_7485(delta.field_1352, delta.field_1351 + delta.method_37267() * .1, delta.field_1350, speed, 2);
        caster.method_73183().method_8649(bolt);
    }
    @Override protected boolean method_26958(class_1297 entity) { return !(entity instanceof MythicHostileEntity) && super.method_26958(entity); }
    @Override protected void method_7454(class_3966 result) {
        super.method_7454(result);
        if (method_73183() instanceof class_3218 level && result.method_17782() instanceof class_1309 target) {
            boolean rock = method_5864() == ModEntities.TROLL_BOULDER;
            float damage = method_24921() instanceof class_1309 owner
                ? (float)owner.method_45325(net.minecraft.class_5134.field_23721) : 4;
            target.method_64397(level, method_48923().method_48811(this, method_24921()), damage);
            if (!rock) target.method_37222(new class_1293(class_1294.field_5899, 60, 0), method_24921());
            else target.method_6005(.7, -method_18798().field_1352, -method_18798().field_1350);
        }
    }
    @Override protected void method_7488(class_239 result) {
        super.method_7488(result);
        if (method_73183() instanceof class_3218 level) {
            level.method_65096(method_5864() == ModEntities.TROLL_BOULDER ? class_2398.field_11204 : class_2398.field_11211,
                method_23317(), method_23318(), method_23321(), 5, .15, .15, .15, .02);
            method_31472();
        }
    }
    @Override public void method_5773() {
        super.method_5773();
        if (!method_73183().method_8608() && field_6012 > 100) method_31472();
        if (method_73183().method_8608() && field_6012 % 3 == 0 && method_5864() == ModEntities.SHAMAN_BOLT)
            method_73183().method_8406(class_2398.field_11211, method_23317(), method_23318(), method_23321(), 0, .01, 0);
    }
}
