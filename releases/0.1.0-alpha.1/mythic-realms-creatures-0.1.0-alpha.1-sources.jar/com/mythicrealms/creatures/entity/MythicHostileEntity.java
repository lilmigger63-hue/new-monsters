package com.mythicrealms.creatures.entity;

import com.mythicrealms.creatures.entity.ai.CreatureCombatGoal;
import com.mythicrealms.creatures.entity.combat.AttackTimeline;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animatable.processing.AnimationController;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public abstract class MythicHostileEntity extends class_1588 implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("walk");
    private static final RawAnimation DEATH = RawAnimation.begin().thenPlayAndHold("death");
    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);
    public final AttackTimeline attack;
    private class_1309 committedTarget;

    protected MythicHostileEntity(class_1299<? extends MythicHostileEntity> type, class_1937 level) {
        super(type, level);
        attack = new AttackTimeline(kind().windup, kind().recovery);
        field_6194 = kind().width >= 1.3 ? 12 : 5;
    }
    public abstract CreatureKind kind();
    public abstract void performAttack(class_3218 level, class_1309 target);
    public boolean reposition(class_1309 target) { return false; }
    public boolean ranged() { return false; }
    public boolean busy() { return false; }
    public boolean tryAttack(class_1309 target) {
        if (!attack.tryStart()) return false;
        committedTarget = target;
        method_5942().method_6340();
        triggerAnim("action", "attack");
        method_5783(kind() == CreatureKind.STONE_TROLL ? class_3417.field_15026 : class_3417.field_14706, .7f, .6f);
        return true;
    }
    @Override protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(2, new CreatureCombatGoal(this));
        field_6201.method_6277(6, new class_1394(this, .8));
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 8));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1399(this));
        field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }
    @Override protected void method_5958(class_3218 level) {
        super.method_5958(level);
        if (committedTarget != null && (!committedTarget.method_5805() || !method_5805())) {
            attack.cancel(); committedTarget = null;
        }
        if (attack.tick()) {
            class_1309 target = committedTarget;
            committedTarget = null;
            if (target != null && target.method_5805() && method_5985().method_6369(target)) performAttack(level, target);
        }
    }
    public void interruptAttack() { attack.cancel(); committedTarget = null; }
    public boolean areaVictim(class_1309 candidate, class_1309 primaryTarget) {
        if (!candidate.method_5805() || candidate == this || method_5722(candidate)) return false;
        if (candidate instanceof class_1657 player && (player.method_68878() || player.method_7325())) return false;
        return candidate == primaryTarget || candidate instanceof class_1657;
    }
    public void melee(class_3218 level, class_1309 target, double reach, double multiplier) {
        if (target.method_5805() && method_5858(target) <= reach * reach && method_5985().method_6369(target)) {
            target.method_64397(level, method_48923().method_48812(this),
                (float)(method_45325(net.minecraft.class_5134.field_23721) * multiplier));
        }
    }
    @Override protected class_3414 method_5994() { return class_3417.field_14976; }
    @Override protected class_3414 method_6011(class_1282 source) { return class_3417.field_15007; }
    @Override protected class_3414 method_6002() { return class_3417.field_15146; }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<MythicHostileEntity>("locomotion", 5, test ->
            test.setAndContinue(test.animatable().method_29504() ? DEATH : test.isMoving() ? WALK : IDLE)));
        controllers.add(new AnimationController<MythicHostileEntity>("action", 2, test -> PlayState.STOP)
            .triggerableAnim("attack", RawAnimation.begin().thenPlay("attack"))
            .triggerableAnim("cast", RawAnimation.begin().thenPlay("cast")));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return animationCache; }
}
