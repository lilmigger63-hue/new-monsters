package com.mythicrealms.creatures.registry;

import com.mythicrealms.creatures.MythicRealmsCreatures;
import com.mythicrealms.creatures.config.CreatureConfig;
import com.mythicrealms.creatures.entity.*;
import net.fabricmc.fabric.api.biome.v1.*;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityType;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1588;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_1959;
import net.minecraft.class_2378;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9169;
import net.minecraft.core.registries.*;
import net.minecraft.resources.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;

public final class ModEntities {
    public static final class_1299<GoblinScoutEntity> GOBLIN_SCOUT = creature(CreatureKind.GOBLIN_SCOUT, GoblinScoutEntity::new);
    public static final class_1299<GoblinShamanEntity> GOBLIN_SHAMAN = creature(CreatureKind.GOBLIN_SHAMAN, GoblinShamanEntity::new);
    public static final class_1299<OrcWarriorEntity> ORC_WARRIOR = creature(CreatureKind.ORC_WARRIOR, OrcWarriorEntity::new);
    public static final class_1299<MinotaurEntity> MINOTAUR = creature(CreatureKind.MINOTAUR, MinotaurEntity::new);
    public static final class_1299<StoneTrollEntity> STONE_TROLL = creature(CreatureKind.STONE_TROLL, StoneTrollEntity::new);
    public static final class_1299<CreatureProjectile> SHAMAN_BOLT = projectile("shaman_bolt", .25f);
    public static final class_1299<CreatureProjectile> TROLL_BOULDER = projectile("troll_boulder", .55f);

    public static class_2960 id(String path) { return class_2960.method_60655(MythicRealmsCreatures.MOD_ID, path); }
    private static <T extends MythicHostileEntity> class_1299<T> creature(CreatureKind kind, class_1299.class_4049<T> factory) {
        var key = class_5321.method_29179(class_7924.field_41266, id(kind.id));
        var rule = CreatureConfig.INSTANCE.spawning.get(kind.id);
        var builder = FabricEntityType.Builder.createMob(factory, class_1311.field_6302, extra -> extra
            .defaultAttributes(() -> kind.attributes(CreatureConfig.INSTANCE.difficultyMultiplier))
            .spawnRestriction(class_9169.field_48745, class_2902.class_2903.field_13203,
                (type, level, reason, pos, random) -> rule.enabled && random.method_43048(rule.frequency) == 0
                    && (kind != CreatureKind.STONE_TROLL || pos.method_10264() < level.method_8410().method_8615() - 8)
                    && class_1588.method_20680(type, level, reason, pos, random)));
        var type = class_2378.method_39197(class_7923.field_41177, key,
            builder.method_17687(kind.width, kind.height).method_27299(8).method_5905(key));
        var itemKey = class_5321.method_29179(class_7924.field_41197, id(kind.id + "_spawn_egg"));
        class_1792 egg = class_2378.method_39197(class_7923.field_41178, itemKey,
            new class_1826(new class_1792.class_1793().method_63686(itemKey).method_72499(type)));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> entries.method_45421(egg));
        if (rule.enabled && rule.weight > 0) {
            class_6862<class_1959> tag = class_6862.method_40092(class_7924.field_41236, id("spawns/" + kind.id));
            BiomeModifications.addSpawn(BiomeSelectors.tag(tag), class_1311.field_6302, type,
                rule.weight, rule.minGroup, rule.maxGroup);
        }
        return type;
    }
    private static class_1299<CreatureProjectile> projectile(String name, float size) {
        var key = class_5321.method_29179(class_7924.field_41266, id(name));
        return class_2378.method_39197(class_7923.field_41177, key,
            class_1299.class_1300.<CreatureProjectile>method_5903(CreatureProjectile::new, class_1311.field_17715)
                .method_17687(size, size).method_27299(6).method_27300(2).method_5905(key));
    }
    public static void initialize() { }
}
